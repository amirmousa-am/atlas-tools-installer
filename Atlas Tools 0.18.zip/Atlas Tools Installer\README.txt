ATLAS TOOLS - HOW TO USE
========================

Atlas Tools opens a separate "WORK" Chrome window and runs your Atlas tools
in it. Your normal Chrome is not changed.


1. INSTALL (one time)
---------------------
1. Right-click the .zip file and choose "Extract All...", then "Extract".
2. Open the extracted folder "Atlas Tools Installer".
3. Double-click "Install Atlas Tools".
   - If Windows says "Windows protected your PC": click "More info",
     then "Run anyway".
4. Wait for the message "Done". Click "Yes" to start Atlas Tools now.

You now have "Atlas Tools" on your desktop and in the Start menu.

If "Install Atlas Tools" does not work (.bat files are blocked):
1. Open the extracted folder "Atlas Tools Installer".
2. Click in the address bar at the top of the window, type  powershell
   and press Enter. A blue window opens.
3. Copy this whole line, paste it in the blue window (right-click pastes)
   and press Enter:

$env:ATLAS_SRC=(Get-Location).ProviderPath; iex ([IO.File]::ReadAllText((Join-Path $env:ATLAS_SRC 'Install-AtlasTools.ps1')))

It does exactly the same as "Install Atlas Tools".


2. EVERY DAY
------------
Double-click "Atlas Tools" on your desktop. That's all.

- A WORK Chrome window opens with Atlas.
- A small dot appears near the clock (bottom-right). If you cannot see it,
  click the small arrow ^ next to the clock.
- Use the WORK Chrome window for Atlas work. Your tools only run there.
- Closing the WORK Chrome window does NOT stop Atlas Tools. To open it
  again: right-click the dot near the clock and choose "Open Atlas".


3. THE FIRST TIME: SIGN IN TO ATLAS
-----------------------------------
The WORK Chrome is a separate Chrome. It does not have your normal
bookmarks or saved passwords.
1. In the WORK Chrome window, sign in to Atlas as usual.
2. Wait a few seconds. Atlas Tools finds your Atlas email by itself
   and downloads the tools assigned to you.
3. You do NOT need to sign in to Chrome itself (the Google account).
You only do this once. Next time you are still signed in.


4. THE DOT NEXT TO YOUR EMAIL IN ATLAS
--------------------------------------
At the top of Atlas, next to your email, there is a small dot.
Click it to switch your tools on or off. Point at it to see details.

  GREEN          All good. Your tools are synced.
  GREY, blinking Syncing your tools. Wait a moment.
  ORANGE         Working, but with a small problem, for example:
                 - the server cannot be reached (your saved tools still work)
                 - no tools are assigned to you yet
                 - still finding your Atlas account
  RED            Not working:
                 - Atlas Tools is not running: double-click "Atlas Tools"
                   on your desktop
                 - or your account is not registered / not active for
                   Atlas Tools: contact the person below
  NO DOT         Atlas Tools is not running. Double-click "Atlas Tools"
                 on your desktop, then reload the Atlas page (F5).

The dot near the clock: GREEN = connected to the WORK Chrome,
ORANGE = waiting for the WORK Chrome.


5. UPDATES
----------
Atlas Tools updates itself.
- When a new version is ready, a message appears near the clock:
  "Atlas Tools update ready". Click it, then click "Yes".
  Or: right-click the dot near the clock, "Restart to update".
- Your WORK Chrome window and tabs stay open.
- If you do nothing, the new version starts the next time you open
  Atlas Tools.

If you get a new .zip file: do step 1 (INSTALL) again. Your tools,
switches and saved tool data are kept.


6. UNINSTALL
------------
1. Right-click the dot near the clock, choose "Quit Atlas Tools".
2. Delete "Atlas Tools" from your desktop.
3. Press the Windows key + R, type  %USERPROFILE%  and press Enter.
4. Delete the folder "Universal-Chrome-Launcher" (your tools and their
   saved data are deleted with it).
5. Optional: also delete the folder "AtlasLauncherProfile" (this is the
   WORK Chrome: your Atlas sign-in there is deleted with it).
6. Optional: in the Start menu, right-click "Atlas Tools",
   "Open file location", and delete the shortcut there.


7. HELP
-------
Contact: [NAME, EMAIL / TEAMS]

Please send:
- a screenshot of the problem
- the version: right-click the dot near the clock, the first line
  shows "Atlas Tools v..."
- the file install-log.txt (Windows key + R, type
  %USERPROFILE%\Universal-Chrome-Launcher  and press Enter)
