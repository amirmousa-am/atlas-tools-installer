# =====================================================================
#  Atlas Tools Launcher (Universal Chrome Productivity Launcher) - v0.18
#  - Runs quietly in the background with an icon near the clock
#  - Tools are switched on/off from the "Tools" button inside Atlas
#  - Ticked tools run on every load of every WORK Chrome tab, including
#    tabs that were already open, respecting @match and @run-at
#  - Opens the WORK Chrome (separate profile, port 9223) if needed;
#    normal Chrome is never touched
#  - Only one copy runs at a time
#  - NEW v0.8: syncs your assigned tools from Supabase (get-my-tools),
#    the same way the old Tampermonkey launcher did; the tools folder
#    is the offline copy
#  - NEW v0.9: tool storage shared across all websites and tabs, with
#    change notifications, and safe image downloads for tools
#    (replaces Tampermonkey's GM_setValue / GM_xmlhttpRequest)
#  - NEW v0.10: downloads run in the background, in parallel, so the
#    launcher never freezes while tools fetch images
#  - NEW v0.11: faster tab-to-tab sync on Windows PowerShell 5.1
#    (fast local tab checks, fast JSON), plus live timing numbers
#  - NEW v0.12: same-website tabs sync instantly inside Chrome; other
#    websites get small changes at once and big ones on demand; every
#    value is time-stamped so old updates never overwrite new ones
#  - NEW v0.13: one connection to the whole WORK Chrome; new tabs and
#    windows get their tools at once; nothing ever waits on a slow tab;
#    Supabase sync runs in the background
#  - NEW v0.14: tabs opened by middle-click, Ctrl+click or 'open in new tab'
#    links get their tools immediately (checked the moment each page starts)
#  - NEW v0.15: tabs Atlas opens on the same website (with a link back to
#    the opener) get all their tools; nothing runs in placeholder pages
#  - NEW v0.16: faster sync of big items (images): small items go to every
#    tab, full images only to visible tabs (others fetch when you switch)
#  - NEW v0.17: shows its version (tray, settings, Atlas panel); the status
#    is a dot next to your email in the Atlas header, like the old launcher
#  - NEW v0.19: synced tools are saved encrypted (tools\*.js.atlas), locked
#    to the user's own Windows account; no readable .js copies on disk
#  - NEW v0.18: fixed file name AtlasTools.ps1 (installed by "Install Atlas
#    Tools.bat"); signed self-update from Supabase Storage (checked at start
#    and every few hours, applied after "Restart to update" in the tray);
#    the installer can close a running copy cleanly
#  File: %USERPROFILE%\Universal-Chrome-Launcher\AtlasTools.ps1
#  Start: double-click the "Atlas Tools" shortcut on the desktop.
#  Does NOT change the execution policy.
# =====================================================================

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
Add-Type -AssemblyName UIAutomationClient
Add-Type -AssemblyName UIAutomationTypes
[System.Windows.Forms.Application]::EnableVisualStyles()
$ProgressPreference = 'SilentlyContinue'
try { Add-Type -AssemblyName System.Web } catch {}
try { Add-Type -AssemblyName System.Net.Http } catch {}
try { Add-Type -AssemblyName System.Security } catch {}
try { [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor [System.Net.SecurityProtocolType]::Tls12 } catch {}

$LauncherVersion = '0.18'
$CdpBase     = 'http://127.0.0.1:9223'
$ProfileMark = 'AtlasLauncherProfile'
$BaseDir     = Join-Path $env:USERPROFILE 'Universal-Chrome-Launcher'
$ToolsDir    = Join-Path $BaseDir 'tools'
$SettingsPath = Join-Path $BaseDir 'launcher-settings.json'
$SupabaseUrl     = 'https://vrhtmogozyumjtctzyzj.supabase.co'
$SupabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InZyaHRtb2dvenl1bWp0Y3R6eXpqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3ODQwMjgxOTMsImV4cCI6MjA5OTYwNDE5M30.hVTMIDXB5bH1M4LkW0K-jMH2Kfe9sd7QH9pvvx-NaF0'
$SyncHours       = 4
$GmDir           = Join-Path $BaseDir 'gm-store'
$GmBigChars      = 65536
$GmSendChars     = 65536
$MaxXhrBytes     = 26214400
$Global:UclSessions = @{}
$Global:UclSettings = $null

# Self-update (v0.18). The public key is filled in by Publisher.ps1; while it is
# empty this copy never updates itself.
$LauncherFile    = Join-Path $BaseDir 'AtlasTools.ps1'
$UpdateBaseUrl   = $SupabaseUrl + '/storage/v1/object/public/launcher-releases/'
$UpdateJsonName  = 'atlas-tools-latest.json'   # separate from the Tampermonkey launcher's version.json
$UpdateHours     = 4
$UpdateMaxBytes  = 3145728
$UpdatePublicKey = '<RSAKeyValue><Modulus>5ij6oy4lbskdqv3YdzMw0vDUOnOyv/Pjy1VzBO58qxAc9av5bCyNOQtbbSfc7Bfr4dqkXdnsJs/JuNCtqEPKXdc8dIZrUK2mkYi6C3Byhv+gM8RYxpt0qhdD7HEe/CYu6x2InCSKEkhQOCYEVCoGGAoaQ49DZF3qiYqq++8yvTY92xvQ955FHNiRHGRLzHWa410YKQoDKDTblh5R32xPVjhi8MwbnwlXxt35Y7l+HzSHut3CT4Dwqu9K5Yn362IaS12vFo4tTwBlvoMLHmV8TxITyZKCRWHxxIVfPIB8bT7w1vUxdlvWPnnjeutYSGkvQ2P7tAqztGFQZc/mKaiXE9j3HQhXO12WoLJ5U7T+z1hO4RH9n1qIAw23/yexcKDaxXcGvVuZw6JNUygyKMc2P4AKvX2aVM2O5gsRB2JuKzrwgL+Dw03uKHjyjNPHLLBd5u89DAmvDYh4gcDJbXpNH5PNJs+Lsfdi3OeelbJfGwWsjh1ZFZfkhnDIJYSC37dx</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'

# Fast JSON text for one string (much faster than ConvertTo-Json on Windows PowerShell 5.1)
function JStr {
    param([string]$Text)
    return [System.Web.HttpUtility]::JavaScriptStringEncode([string]$Text, $true)
}

# Local Chrome questions go straight to 127.0.0.1: no proxy lookup, no progress bar
function Get-CdpJson {
    param([string]$Path)
    if (-not $Global:UclLocalHttp) {
        $h = New-Object System.Net.Http.HttpClientHandler
        $h.UseProxy = $false
        $c = New-Object System.Net.Http.HttpClient($h)
        $c.Timeout = [TimeSpan]::FromSeconds(3)
        $Global:UclLocalHttp = $c
    }
    $t = $Global:UclLocalHttp.GetStringAsync($CdpBase + $Path)
    if (-not $t.Wait(3000)) { throw 'WORK Chrome did not answer' }
    return ($t.Result | ConvertFrom-Json)
}

# ---------------------------------------------------------------------
#  CDP: version + real web pages (each target checked separately)
# ---------------------------------------------------------------------
function Get-CdpInfo {
    param([switch]$WithVersion)
    $info = [ordered]@{ Connected = $false; Browser = ''; Pages = @(); Error = '' }
    try {
        $raw = Get-CdpJson '/json/list'
        $all = @($raw | ForEach-Object { $_ })
        $info.Pages = @($all | Where-Object {
            $_.type -eq 'page' -and
            [string]$_.url -notmatch '^(chrome|chrome-extension|devtools|chrome-untrusted)://'
        })
        if ($WithVersion) { $info.Browser = [string](Get-CdpJson '/json/version').Browser }
        $info.Connected = $true
    } catch {
        $info.Error = $_.Exception.GetBaseException().Message
    }
    return [pscustomobject]$info
}

# ---------------------------------------------------------------------
#  UI Automation: WORK Chrome window and its selected tab
# ---------------------------------------------------------------------
function Get-WorkSelection {
    $r = [ordered]@{ Ok = $false; Reason = ''; WindowCount = 0; WindowTitle = ''; WindowState = ''; CleanTab = ''; CleanTabs = @(); SelectedCount = 0; Url = '' }
    try {
        $workPids = @(Get-CimInstance Win32_Process -Filter "Name='chrome.exe'" |
            Where-Object { $_.CommandLine -match $ProfileMark } |
            ForEach-Object { [int]$_.ProcessId })
        if ($workPids.Count -eq 0) { $r.Reason = 'WORK Chrome is not running.'; return [pscustomobject]$r }

        $AE      = [System.Windows.Automation.AutomationElement]
        $winCond = New-Object System.Windows.Automation.PropertyCondition($AE::ClassNameProperty, 'Chrome_WidgetWin_1')
        $tabCond = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::TabItem)

        $wins = @()
        foreach ($w in $AE::RootElement.FindAll([System.Windows.Automation.TreeScope]::Children, $winCond)) {
            if ($workPids -contains [int]$w.Current.ProcessId -and -not [string]::IsNullOrWhiteSpace($w.Current.Name)) { $wins += $w }
        }
        $r.WindowCount = $wins.Count
        if ($wins.Count -eq 0) { $r.Reason = 'No WORK Chrome window found.'; return [pscustomobject]$r }
        if ($wins.Count -gt 1) { $r.Reason = 'More than one WORK Chrome window is open (ambiguous). Keep only one WORK window open.'; return [pscustomobject]$r }

        $win = $wins[0]
        $r.WindowTitle = $win.Current.Name
        try { $r.WindowState = [string]$win.GetCurrentPattern([System.Windows.Automation.WindowPattern]::Pattern).Current.WindowVisualState } catch { $r.WindowState = 'n/a' }

        # Read the address bar first (it always shows the active tab's URL)
        $editCond = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::Edit)
        foreach ($e in $win.FindAll([System.Windows.Automation.TreeScope]::Descendants, $editCond)) {
            if ($e.Current.Name -eq 'Address and search bar') {
                try { $r.Url = [string]$e.GetCurrentPattern([System.Windows.Automation.ValuePattern]::Pattern).Current.Value } catch {}
                break
            }
        }

        $selected = @()
        foreach ($t in $win.FindAll([System.Windows.Automation.TreeScope]::Descendants, $tabCond)) {
            try {
                if ($t.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Current.IsSelected) {
                    $selected += ([string]$t.Current.Name -replace '\s+-\s+Memory usage\s+-\s+[\d.,]+\s*[KMG]B$', '')
                }
            } catch {}
        }
        $r.SelectedCount = $selected.Count
        $r.CleanTabs = $selected
        $r.CleanTab  = ($selected -join ' | ')

        if ($selected.Count -eq 0) { $r.Reason = 'No selected tab found in WORK window.'; return [pscustomobject]$r }
        if ($selected.Count -gt 1 -and -not $r.Url) {
            $r.Reason = 'Chrome reports ' + $selected.Count + ' selected tabs and the address bar could not be read.'
            return [pscustomobject]$r
        }
        $r.Ok = $true
    } catch {
        $r.Reason = 'UI Automation error: ' + $_.Exception.Message
    }
    return [pscustomobject]$r
}

# ---------------------------------------------------------------------
#  Match selected tab to exactly ONE CDP target (with safety checks)
# ---------------------------------------------------------------------
function Get-NormalUrl {
    param([string]$Url)
    $u = $Url.Trim()
    try { $u = [Uri]::UnescapeDataString($u) } catch {}
    $u = $u -replace '^[a-zA-Z]+://', ''
    $u = $u -replace '^www\.', ''
    $u = $u.TrimEnd('/')
    return $u.ToLowerInvariant()
}

function Find-MatchingTarget {
    param($Selection, $Cdp)
    $m = [ordered]@{ Status = 'BLOCKED'; Detail = ''; Target = $null }
    if (-not $Cdp.Connected) { $m.Detail = 'CDP not connected: ' + $Cdp.Error; return [pscustomobject]$m }
    if (-not $Selection.Ok)  { $m.Detail = $Selection.Reason; return [pscustomobject]$m }

    # Step A: title must match
    $names = @($Selection.CleanTabs)
    $hits = @(@($Cdp.Pages) | Where-Object { $names -contains [string]$_.title })
    $titleCount = $hits.Count

    # Step B: if the address bar was read, the URL must match too
    if ($Selection.Url) {
        $want = Get-NormalUrl $Selection.Url
        $hits = @($hits | Where-Object { (Get-NormalUrl ([string]$_.url)) -eq $want })
    }

    if ($titleCount -eq 0) {
        $m.Status = 'NO MATCH'
        $m.Detail = 'No CDP page has the title "' + $Selection.CleanTab + '".'
    } elseif ($hits.Count -eq 0) {
        $m.Status = 'NO MATCH'
        $m.Detail = 'Title matched ' + $titleCount + ' page(s), but none has the address-bar URL.'
    } elseif ($hits.Count -gt 1) {
        $m.Status = 'AMBIGUOUS'
        if ($Selection.Url) {
            $m.Detail = [string]$hits.Count + ' tabs have the same title AND the same URL. Close the duplicate tab.'
        } else {
            $m.Detail = [string]$hits.Count + ' tabs share the title and the address bar could not be read.'
        }
    } elseif (-not (($hits[0].id -is [string]) -and ($hits[0].id -match '^[A-F0-9]{32}$'))) {
        $m.Detail = 'Target ID failed safety check.'
    } elseif ([string]$hits[0].webSocketDebuggerUrl -notmatch '^ws://127\.0\.0\.1:9223/devtools/page/') {
        $m.Detail = 'Target has no local debugger address (is DevTools open on that tab? Close it).'
    } else {
        $m.Status = 'MATCHED'
        $m.Detail = 'Exactly one verified target.'
        $m.Target = $hits[0]
    }
    return [pscustomobject]$m
}

# ---------------------------------------------------------------------
#  Run one JavaScript expression on one verified target (via CDP)
# ---------------------------------------------------------------------
function Invoke-CdpEvaluate {
    param([string]$WsUrl, [string]$Expression)
    $ws  = New-Object System.Net.WebSockets.ClientWebSocket
    $cts = New-Object System.Threading.CancellationTokenSource
    $cts.CancelAfter(5000)
    try {
        $ws.ConnectAsync([Uri]$WsUrl, $cts.Token).Wait()
        $msg = @{ id = 1; method = 'Runtime.evaluate'; params = @{ expression = $Expression; returnByValue = $true } } | ConvertTo-Json -Compress -Depth 5
        $bytes = [System.Text.Encoding]::UTF8.GetBytes($msg)
        $seg = New-Object System.ArraySegment[byte] -ArgumentList (,$bytes)
        $ws.SendAsync($seg, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, $cts.Token).Wait()

        $buf = New-Object byte[] 65536
        $sb  = New-Object System.Text.StringBuilder
        while ($true) {
            $rseg = New-Object System.ArraySegment[byte] -ArgumentList (,$buf)
            $res  = $ws.ReceiveAsync($rseg, $cts.Token).Result
            [void]$sb.Append([System.Text.Encoding]::UTF8.GetString($buf, 0, $res.Count))
            if ($res.EndOfMessage) {
                $obj = $sb.ToString() | ConvertFrom-Json
                if ($obj.id -eq 1) { return $obj }
                [void]$sb.Clear()
            }
        }
    } finally {
        try { $ws.Dispose() } catch {}
        $cts.Dispose()
    }
}

# ---------------------------------------------------------------------
#  Tools: list files and wrap code with double-load protection
# ---------------------------------------------------------------------
# Synced tools are kept encrypted on disk (tools\<name>.js.atlas), locked to this
# Windows account (DPAPI): the files cannot be read or used on another account or PC.
# Tools the user added by hand as plain .js files still work as before.
$ToolEncExt  = '.atlas'
$ToolEntropy = [System.Text.Encoding]::UTF8.GetBytes('AtlasTools/tools/v1')

function Protect-ToolText {
    param([string]$Text)
    return [System.Security.Cryptography.ProtectedData]::Protect([System.Text.Encoding]::UTF8.GetBytes($Text), $ToolEntropy, [System.Security.Cryptography.DataProtectionScope]::CurrentUser)
}

function Unprotect-ToolBytes {
    param([byte[]]$Bytes)
    return [System.Text.Encoding]::UTF8.GetString([System.Security.Cryptography.ProtectedData]::Unprotect($Bytes, $ToolEntropy, [System.Security.Cryptography.DataProtectionScope]::CurrentUser))
}

# Save a synced tool (encrypted) and remove any readable copy of it
function Save-CloudTool {
    param([string]$File, [string]$Code)
    if (-not (Test-Path -LiteralPath $ToolsDir)) { New-Item -ItemType Directory -Path $ToolsDir | Out-Null }
    $enc = Join-Path $ToolsDir ($File + $ToolEncExt)
    $tmp = $enc + '.tmp'
    [System.IO.File]::WriteAllBytes($tmp, (Protect-ToolText $Code))
    if (Test-Path -LiteralPath $enc) { Remove-Item -LiteralPath $enc -Force }
    [System.IO.File]::Move($tmp, $enc)
    $plain = Join-Path $ToolsDir $File
    if (Test-Path -LiteralPath $plain) { Remove-Item -LiteralPath $plain -Force -ErrorAction SilentlyContinue }
}

function Remove-CloudTool {
    param([string]$File)
    foreach ($p in @((Join-Path $ToolsDir $File), (Join-Path $ToolsDir ($File + $ToolEncExt)))) {
        if (Test-Path -LiteralPath $p) { Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue }
    }
}

function Test-ToolExists {
    param([string]$Name)
    return ((Test-Path -LiteralPath (Join-Path $ToolsDir $Name)) -or (Test-Path -LiteralPath (Join-Path $ToolsDir ($Name + $ToolEncExt))))
}

# Every tool: Name is always "<tool>.js" (the same names as before, so settings keep working)
function Get-ToolFiles {
    if (-not (Test-Path -LiteralPath $ToolsDir)) {
        New-Item -ItemType Directory -Path $ToolsDir | Out-Null
    }
    $cloud = @()
    if ($Global:UclSettings) { $cloud = @($Global:UclSettings.cloud) }
    $plainFiles = @(Get-ChildItem -LiteralPath $ToolsDir -File | Where-Object { $_.Name -like '*.js' })
    # Readable copies of synced tools (from older versions): encrypt them now
    foreach ($f in $plainFiles) {
        if ($cloud -contains $f.Name) {
            try { Save-CloudTool -File $f.Name -Code ([System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8)) } catch { $Global:UclLastError = 'Could not encrypt ' + $f.Name + ': ' + $_.Exception.Message }
        }
    }
    $list = @{}
    foreach ($f in @(Get-ChildItem -LiteralPath $ToolsDir -File | Where-Object { $_.Name -like ('*.js' + $ToolEncExt) })) {
        $n = $f.Name.Substring(0, $f.Name.Length - $ToolEncExt.Length)
        $list[$n] = [pscustomobject]@{ Name = $n; BaseName = [System.IO.Path]::GetFileNameWithoutExtension($n); FullName = $f.FullName; Encrypted = $true }
    }
    foreach ($f in @(Get-ChildItem -LiteralPath $ToolsDir -File | Where-Object { $_.Name -like '*.js' })) {
        if (-not $list.ContainsKey($f.Name)) {
            $list[$f.Name] = [pscustomobject]@{ Name = $f.Name; BaseName = $f.BaseName; FullName = $f.FullName; Encrypted = $false }
        }
    }
    return @($list.Values | Sort-Object Name)
}

function Read-ToolCode {
    param($File)
    if ($File.Encrypted) { return (Unprotect-ToolBytes ([System.IO.File]::ReadAllBytes($File.FullName))) }
    return [System.IO.File]::ReadAllText($File.FullName, [System.Text.Encoding]::UTF8)
}

function New-ToolExpression {
    param([string]$ToolName, [string]$Code)
    $key = $ToolName | ConvertTo-Json -Compress
    $nl = "`n"
    return '(function () {' + $nl +
        '  var key = ' + $key + ';' + $nl +
        '  var reg = window.__UCL_TOOLS__ = window.__UCL_TOOLS__ || {};' + $nl +
        '  var report = function (s) { return JSON.stringify({ status: s, loaded: Object.keys(reg) }); };' + $nl +
        '  if (reg[key]) { return report("ALREADY LOADED"); }' + $nl +
        '  reg[key] = new Date().toISOString();' + $nl +
        '  try {' + $nl +
        '    (function () {' + $nl +
        $Code + $nl +
        '    })();' + $nl +
        '  } catch (e) {' + $nl +
        '    delete reg[key];' + $nl +
        '    return report("ERROR: " + (e && e.message ? e.message : String(e)));' + $nl +
        '  }' + $nl +
        '  return report("LOADED");' + $nl +
        '})()'
}


# ---------------------------------------------------------------------
#  v0.5 SETTINGS (ticked tools + auto-load switch)
# ---------------------------------------------------------------------
function Read-Settings {
    $st = [pscustomobject]@{ checked = @(); autoload = $true; email = ''; cloud = @(); known = @(); lastSync = ''; token = '' }
    try {
        if (Test-Path -LiteralPath $SettingsPath) {
            $raw = Get-Content -LiteralPath $SettingsPath -Raw | ConvertFrom-Json
            $st.checked = @($raw.checked | Where-Object { $_ } | ForEach-Object { [string]$_ })
            if ($raw.email) { $st.email = [string]$raw.email }
            $st.cloud = @($raw.cloud | Where-Object { $_ } | ForEach-Object { [string]$_ })
            $st.known = @($raw.known | Where-Object { $_ } | ForEach-Object { [string]$_ })
            $ls = $raw.lastSync
            if ($ls -is [datetime]) { $st.lastSync = $ls.ToString('yyyy-MM-ddTHH:mm:ssK') } elseif ($ls) { $st.lastSync = [string]$ls }
            if ($raw.token) { $st.token = [string]$raw.token }
        }
    } catch {}
    return $st
}

function Format-JsonArray {
    param($Items)
    return '[' + ((@($Items) | Where-Object { $_ } | ForEach-Object { [string]$_ | ConvertTo-Json -Compress }) -join ',') + ']'
}

function Save-Settings {
    try {
        $s = $Global:UclSettings
        $nl = [Environment]::NewLine
        $json = '{' + $nl +
            '  "checked": ' + (Format-JsonArray $s.checked) + ',' + $nl +
            '  "autoload": true,' + $nl +
            '  "email": ' + ([string]$s.email | ConvertTo-Json -Compress) + ',' + $nl +
            '  "cloud": ' + (Format-JsonArray $s.cloud) + ',' + $nl +
            '  "known": ' + (Format-JsonArray $s.known) + ',' + $nl +
            '  "lastSync": ' + ([string]$s.lastSync | ConvertTo-Json -Compress) + ',' + $nl +
            '  "token": ' + ([string]$s.token | ConvertTo-Json -Compress) + $nl + '}'
        [System.IO.File]::WriteAllText($SettingsPath, $json, (New-Object System.Text.UTF8Encoding($false)))
    } catch {}
}

# ---------------------------------------------------------------------
#  BUNDLE: ticked tools + the in-page "Tools" panel, in one script
# ---------------------------------------------------------------------
function Convert-MatchToRegex {
    param([string]$Pattern)
    $esc = [Regex]::Escape($Pattern) -replace '\\\*', '.*'
    return '^' + $esc + '$'
}

function Get-ToolHeader {
    param([string]$Code)
    $h = [pscustomobject]@{ Matches = @(); RunAt = 'document-idle'; Name = ''; Description = '' }
    $m = [Regex]::Match($Code, '(?s)==UserScript==(.*?)==/UserScript==')
    if ($m.Success) {
        $hdr = $m.Groups[1].Value
        $h.Matches = @([Regex]::Matches($hdr, '@(?:match|include)\s+(\S+)') | ForEach-Object { $_.Groups[1].Value })
        $r = [Regex]::Match($hdr, '@run-at\s+(\S+)')
        if ($r.Success) { $h.RunAt = $r.Groups[1].Value }
        $n = [Regex]::Match($hdr, '@name\s+([^\r\n]+)')
        if ($n.Success) { $h.Name = $n.Groups[1].Value.Trim() }
        $d = [Regex]::Match($hdr, '@description\s+([^\r\n]+)')
        if ($d.Success) { $h.Description = $d.Groups[1].Value.Trim() }
    }
    return $h
}

$UclBundleHead = @'
(function () {
  if (window.top !== window.self) return;
  // Only real web pages: never the empty placeholder a new tab shows for a moment
  if (!/^https?:$/.test(location.protocol)) return;
  // A browser may reuse the window object when a placeholder page becomes the real page
  // (same website, opened with a link back). Start clean for each new page.
  if (window.__UCL_DOC__ !== document) {
    if (window.__UCL_PANEL_TIMER__) { try { clearInterval(window.__UCL_PANEL_TIMER__); } catch (e) {} }
    ['__UCL_TOOLS__', '__UCL_GMS__', '__UCL_BC__', '__UCL_BC_ON__', '__UCL_PANEL_TIMER__', '__UCL_PENDING__', '__UCL_HELLO__', '__UCL_SYNCING__', '__UCL_MSG__'].forEach(function (k) {
      try { delete window[k]; } catch (e) { window[k] = undefined; }
    });
    window.__UCL_DOC__ = document;
  }
  var TOKEN = '__UCL_TOKEN__';
  var realSend = (typeof window.__uclSend === 'function') ? window.__uclSend : null;
  function sendSecure(obj) {
    var f = realSend || (typeof window.__uclSend === 'function' ? window.__uclSend : null);
    if (!f) return false;
    obj.token = TOKEN;
    obj.at = Date.now();
    try { f(JSON.stringify(obj)); return true; } catch (e) { return false; }
  }
  var reg = window.__UCL_TOOLS__ = window.__UCL_TOOLS__ || {};

  // ---- Shared tool storage (kept by the launcher, the same on every website) ----
  // Every value carries a stamp (time-based); a newer stamp always wins, so late
  // or repeated updates can never overwrite newer data or bring deleted data back.
  var GMS = window.__UCL_GMS__ = window.__UCL_GMS__ || { data: {}, big: {}, stamp: {}, listeners: {}, loaded: false, snapAt: 0, lid: 0, xhr: {}, xid: 0, seq: 0 };
  function jparse(j) { if (j === undefined || j === null) return undefined; try { return JSON.parse(j); } catch (e) { return undefined; } }
  function has(o, k) { return !!o && Object.prototype.hasOwnProperty.call(o, k); }
  function bucket(name, tool) { var m = GMS[name]; return m[tool] = m[tool] || {}; }
  function newStamp() { GMS.seq = (GMS.seq + 1) % 1000; return Date.now() * 1000 + GMS.seq; }
  function gmLoad() {
    if (GMS.loaded) return;
    var snap = window.__UCL_GM_SNAPSHOT__;
    if (!snap || !snap.tools) return;
    GMS.loaded = true;
    GMS.snapAt = snap.at || 0;
    Object.keys(snap.tools).forEach(function (tool) {
      var t = snap.tools[tool] || {};
      Object.keys(t.v || {}).forEach(function (k) { setRemote(tool, k, t.v[k][0], t.v[k][1], false, false); });
      Object.keys(t.b || {}).forEach(function (k) { setRemote(tool, k, null, t.b[k], true, false); });
      Object.keys(t.d || {}).forEach(function (k) { setRemote(tool, k, null, t.d[k], false, false); });
    });
  }
  // Big items (images): visible tabs fetch them at once, background tabs when they are shown
  GMS.waiting = GMS.waiting || {};
  GMS.asked = GMS.asked || {};
  function needBig(tool, k) {
    if (document.visibilityState === 'visible') {
      var id = tool + '\n' + k, now = Date.now();
      if (GMS.asked[id] && now - GMS.asked[id] < 2000) return;
      GMS.asked[id] = now;
      sendSecure({ action: 'gm_need', tool: tool, keys: [k] });
    } else {
      (GMS.waiting[tool] = GMS.waiting[tool] || {})[k] = true;
    }
  }
  function reportVisible() { sendSecure({ action: 'vis', tool: '-', visible: document.visibilityState === 'visible' }); }
  if (!GMS.visHooked) {
    GMS.visHooked = true;
    reportVisible();
    document.addEventListener('visibilitychange', function () {
      reportVisible();
      if (document.visibilityState !== 'visible') return;
      Object.keys(GMS.waiting).forEach(function (tool) {
        var keys = Object.keys(GMS.waiting[tool]).filter(function (k) { return GMS.big[tool] && GMS.big[tool][k]; });
        GMS.waiting[tool] = {};
        if (keys.length) sendSecure({ action: 'gm_need', tool: tool, keys: keys });
      });
    });
  }
  function fire(tool, k, oldJ, newJ, remote) {
    var ls = (GMS.listeners[tool] || {})[k];
    if (!ls) return;
    var o = jparse(oldJ), n = jparse(newJ);
    Object.keys(ls).forEach(function (id) { try { ls[id](k, o, n, remote); } catch (e) { console.error('[Atlas Tools] listener error', e); } });
  }
  // Apply a change that came from another tab (j === null and !big means deleted)
  function setRemote(tool, k, j, stamp, big, notify) {
    var st = bucket('stamp', tool);
    if (has(st, k) && st[k] >= stamp) return false;
    st[k] = stamp;
    var d = bucket('data', tool), b = bucket('big', tool);
    var old = d[k];
    if (big) { delete d[k]; b[k] = true; if (notify) needBig(tool, k); return true; }
    delete b[k];
    if (j === null) { delete d[k]; } else { d[k] = j; }
    var now = (j === null) ? undefined : j;
    if (notify && old !== now) fire(tool, k, old, now, true);
    return true;
  }
  // Same-website tabs: instant, directly inside Chrome
  var bc = null;
  try { bc = window.__UCL_BC__ = window.__UCL_BC__ || new BroadcastChannel('ucl-gm-v1'); } catch (e) { bc = null; }
  if (bc && !window.__UCL_BC_ON__) {
    window.__UCL_BC_ON__ = true;
    bc.onmessage = function (ev) {
      var m = ev && ev.data;
      if (!m || m.ucl !== 1) return;
      gmLoad();
      setRemote(m.tool, m.k, m.j, m.s, false, true);
    };
  }
  function shareLocal(tool, k, j, stamp) {
    if (bc) { try { bc.postMessage({ ucl: 1, tool: tool, k: k, j: j, s: stamp }); } catch (e) {} }
  }
  // Other websites: through the launcher
  window.__UCL_GM_APPLY__ = function (tool, k, j, stamp, big) { gmLoad(); setRemote(tool, k, j, stamp || 0, !!big, true); };
  window.__UCL_GM_BATCH__ = function (tool, rows) { gmLoad(); (rows || []).forEach(function (r) { setRemote(tool, r[0], r[1], r[2], !!r[3], true); }); };
  window.__UCL_GM_FILL__ = function (tool, vals) {
    var d = bucket('data', tool), b = bucket('big', tool), st = bucket('stamp', tool);
    Object.keys(vals || {}).forEach(function (k) {
      var j = vals[k][0], s = vals[k][1];
      if (!b[k] || (has(st, k) && st[k] > s)) return;
      delete b[k]; d[k] = j; st[k] = s;
      fire(tool, k, undefined, j, true);
    });
  };
  window.__UCL_XHR_DONE__ = function (id, r) {
    var d = GMS.xhr[id];
    if (!d) return;
    delete GMS.xhr[id];
    if (!r || r.error) {
      var info = { status: 0, error: r ? r.error : 'failed', finalUrl: d.url };
      if (r && r.timeout && d.ontimeout) d.ontimeout(info); else if (d.onerror) d.onerror(info);
      if (d.onloadend) d.onloadend(info);
      return;
    }
    var resp = { status: r.status, statusText: r.statusText || '', finalUrl: r.finalUrl || d.url, responseHeaders: r.headers || '', readyState: 4 };
    var rt = String(d.responseType || '').toLowerCase();
    var bin = atob(r.b64 || ''), arr = new Uint8Array(bin.length);
    for (var i = 0; i < bin.length; i++) arr[i] = bin.charCodeAt(i);
    if (rt === 'blob') { resp.response = new Blob([arr], { type: r.type || '' }); }
    else if (rt === 'arraybuffer') { resp.response = arr.buffer; }
    else {
      var text = '';
      try { text = new TextDecoder('utf-8').decode(arr); } catch (e) { text = bin; }
      resp.responseText = text;
      resp.response = rt === 'json' ? jparse(text) : text;
    }
    if (d.onload) d.onload(resp);
    if (d.onloadend) d.onloadend(resp);
  };

  var NAMES = ['GM_addStyle','GM_setValue','GM_getValue','GM_deleteValue','GM_listValues','GM_setClipboard','GM_openInTab','GM_addValueChangeListener','GM_removeValueChangeListener','GM_registerMenuCommand','GM_notification','GM_xmlhttpRequest','GM','unsafeWindow'];
  function makeGM(key) {
    function copyFallback(t) {
      try { var a = document.createElement('textarea'); a.value = t; document.body.appendChild(a); a.select(); document.execCommand('copy'); a.remove(); } catch (e) {}
    }
    var api = {
      GM_addStyle: function (css) { var s = document.createElement('style'); s.textContent = css; (document.head || document.documentElement).appendChild(s); return s; },
      GM_setValue: function (k, v) {
        gmLoad(); k = String(k);
        var j; try { j = JSON.stringify(v === undefined ? null : v); } catch (e) { return; }
        var d = bucket('data', key), b = bucket('big', key), st = bucket('stamp', key);
        var old = d[k], s = newStamp();
        delete b[k]; d[k] = j; st[k] = s;
        shareLocal(key, k, j, s);
        sendSecure({ action: 'gm_set', tool: key, key: k, v: j, s: s });
        if (old !== j) fire(key, k, old, j, false);
      },
      GM_getValue: function (k, def) {
        gmLoad(); k = String(k);
        var d = GMS.data[key];
        if (has(d, k)) { var r = jparse(d[k]); return r === undefined ? def : r; }
        if (GMS.big[key] && GMS.big[key][k]) needBig(key, k);
        return def;
      },
      GM_deleteValue: function (k) {
        gmLoad(); k = String(k);
        var d = bucket('data', key), b = bucket('big', key), st = bucket('stamp', key);
        var had = has(d, k) || !!b[k];
        var old = d[k], s = newStamp();
        delete d[k]; delete b[k]; st[k] = s;
        shareLocal(key, k, null, s);
        sendSecure({ action: 'gm_del', tool: key, key: k, s: s });
        if (had) fire(key, k, old, undefined, false);
      },
      GM_listValues: function () {
        gmLoad();
        var out = Object.keys(GMS.data[key] || {});
        Object.keys(GMS.big[key] || {}).forEach(function (k) { if (out.indexOf(k) < 0) out.push(k); });
        return out;
      },
      GM_setClipboard: function (t) { t = String(t); try { var p = navigator.clipboard && navigator.clipboard.writeText(t); if (p && p.catch) { p.catch(function () { copyFallback(t); }); } else { copyFallback(t); } } catch (e) { copyFallback(t); } },
      GM_openInTab: function (url, opts) { var w = window.open(url, '_blank'); return { close: function () { try { if (w) w.close(); } catch (e) {} } }; },
      GM_addValueChangeListener: function (k, cb) {
        var l = GMS.listeners[key] = GMS.listeners[key] || {};
        var m = l[String(k)] = l[String(k)] || {};
        var id = ++GMS.lid;
        m[id] = cb;
        return id;
      },
      GM_removeValueChangeListener: function (id) {
        var l = GMS.listeners[key] || {};
        Object.keys(l).forEach(function (k) { delete l[k][id]; });
      },
      GM_xmlhttpRequest: function (d) {
        d = d || {};
        var id = ++GMS.xid;
        var url = String(d.url || '');
        try { url = new URL(url, location.href).href; } catch (e) {}
        var hdrs = {};
        if (d.headers) Object.keys(d.headers).forEach(function (h) { hdrs[h] = String(d.headers[h]); });
        GMS.xhr[id] = d;
        var ok = sendSecure({ action: 'xhr', id: id, tool: key, method: String(d.method || 'GET').toUpperCase(), url: url, headers: hdrs, timeout: d.timeout || 30000 });
        if (!ok) {
          delete GMS.xhr[id];
          setTimeout(function () { if (d.onerror) d.onerror({ status: 0, error: 'Atlas Tools is not running', finalUrl: url }); }, 0);
        } else {
          setTimeout(function () { if (GMS.xhr[id]) window.__UCL_XHR_DONE__(id, { error: 'Download timed out', timeout: true }); }, (d.timeout || 30000) + 15000);
        }
        return { abort: function () { if (GMS.xhr[id]) { delete GMS.xhr[id]; if (d.onabort) d.onabort({ status: 0 }); } } };
      },
      GM_registerMenuCommand: function () {},
      GM_notification: function () {},
      unsafeWindow: window
    };
    api.GM = {
      getValue: function (k, d) { return Promise.resolve(api.GM_getValue(k, d)); },
      setValue: function (k, v) { api.GM_setValue(k, v); return Promise.resolve(); },
      deleteValue: function (k) { api.GM_deleteValue(k); return Promise.resolve(); },
      listValues: function () { return Promise.resolve(api.GM_listValues()); },
      xmlHttpRequest: api.GM_xmlhttpRequest,
      addStyle: api.GM_addStyle,
      setClipboard: api.GM_setClipboard,
      openInTab: api.GM_openInTab
    };
    return api;
  }
  function matches(t) {
    if (!t.match.length) return true;
    for (var i = 0; i < t.match.length; i++) { if (new RegExp(t.match[i]).test(location.href)) return true; }
    return false;
  }
  function start(t) {
    if (reg[t.key] || !matches(t)) return;
    reg[t.key] = new Date().toISOString();
    gmLoad();
    sendSecure({ action: 'gm_catchup', tool: t.key, since: GMS.snapAt || 0 });
    Object.keys(GMS.big[t.key] || {}).forEach(function (k) { needBig(t.key, k); });
    // Tampermonkey always starts tools before the page finishes loading. If we are later than
    // that, run any "on load" / "on DOMContentLoaded" callbacks the tool registers right away.
    var wAdd = window.addEventListener, dAdd = document.addEventListener;
    function late(type, fn, target) {
      var st = document.readyState;
      if ((type === 'load' && st === 'complete') || (type === 'DOMContentLoaded' && st !== 'loading')) {
        setTimeout(function () { try { if (typeof fn === 'function') fn.call(target, new Event(type)); else if (fn && fn.handleEvent) fn.handleEvent(new Event(type)); } catch (e) { console.error('[Launcher] ' + t.key, e); } }, 0);
        return true;
      }
      return false;
    }
    window.addEventListener = function (type, fn, o) { if (late(type, fn, window)) return; return wAdd.call(this, type, fn, o); };
    document.addEventListener = function (type, fn, o) { if (late(type, fn, document)) return; return dAdd.call(this, type, fn, o); };
    try { var gm = makeGM(t.key); t.run.apply(window, NAMES.map(function (n) { return gm[n]; })); }
    catch (e) { delete reg[t.key]; console.error('[Launcher] Tool failed: ' + t.key, e); }
    finally { window.addEventListener = wAdd; document.addEventListener = dAdd; }
  }
  var tools = [];
'@


$UclBundleTail = @'
  tools.forEach(function (t) { if (t.runAt === 'document-start') start(t); });
  var rest = function () { tools.forEach(function (t) { if (t.runAt !== 'document-start') start(t); }); };
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', rest); } else { rest(); }

  // ---------------- In-page "Tools" panel (Atlas pages only) ----------------
  if (location.hostname !== 'atlas.almosafer.com') return;
  window.__UCL_MSG__ = '';
  var pending = window.__UCL_PENDING__ = window.__UCL_PENDING__ || {};
  var OPEN_KEY = 'ucl_panel_open';
  var CSS = [
    ':host{all:initial}',
    '.pill{display:flex;align-items:center;gap:7px;font:600 12px/1 "Segoe UI",Arial,sans-serif;color:#0f172a;background:#fff;border:1px solid #cbd5e1;border-radius:999px;padding:8px 12px;box-shadow:0 4px 14px rgba(15,23,42,.18);cursor:pointer}',
    '.pill:hover{background:#f8fafc}',
    '.dot{width:8px;height:8px;border-radius:50%;display:inline-block}',
    '.dot.ok{background:#22c55e}.dot.off{background:#ef4444}',
    '.panel{display:none;position:absolute;left:0;bottom:44px;width:310px;max-height:60vh;overflow:auto;background:#fff;color:#0f172a;border:1px solid #e2e8f0;border-radius:12px;box-shadow:0 12px 32px rgba(15,23,42,.22);font:13px/1.4 "Segoe UI",Arial,sans-serif}',
    '.head{padding:12px 14px 10px;border-bottom:1px solid #f1f5f9}',
    '.title{font-weight:700;font-size:14px}',
    '.sub{font-size:11px;margin-top:2px}.sub.ok{color:#16a34a}.sub.off{color:#dc2626}',
    '.list{padding:6px 8px}',
    '.row{display:flex;gap:10px;align-items:flex-start;padding:8px 6px;border-radius:8px;cursor:pointer}',
    '.row:hover{background:#f8fafc}',
    '.sw{appearance:none;-webkit-appearance:none;flex:0 0 34px;width:34px;height:20px;border-radius:999px;background:#cbd5e1;position:relative;cursor:pointer;margin:1px 0 0;transition:background .15s}',
    '.sw:before{content:"";position:absolute;top:2px;left:2px;width:16px;height:16px;border-radius:50%;background:#fff;box-shadow:0 1px 2px rgba(0,0,0,.25);transition:transform .15s}',
    '.sw:checked{background:#2563eb}.sw:checked:before{transform:translateX(14px)}',
    '.sw:disabled{opacity:.55;cursor:default}',
    '.txt{min-width:0}',
    '.name{font-weight:600}',
    '.desc{font-size:11px;color:#64748b;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}',
    '.chip{display:inline-block;margin-top:4px;font-size:10px;font-weight:600;padding:1px 7px;border-radius:999px}',
    '.chip.on{background:#dcfce7;color:#166534}.chip.idle{background:#f1f5f9;color:#64748b}.chip.warn{background:#ffedd5;color:#9a3412}.chip.busy{background:#dbeafe;color:#1e40af}',
    '.empty{padding:10px 6px;color:#64748b;font-size:12px}',
    '.foot{padding:10px 14px;border-top:1px solid #f1f5f9}',
    '.msg{font-size:11px;color:#b91c1c;margin-bottom:6px}',
    '.reload{width:100%;padding:7px;border:0;border-radius:8px;background:#0f172a;color:#fff;font:600 12px "Segoe UI",Arial,sans-serif;cursor:pointer;margin-bottom:6px}',
    '.link{width:100%;padding:6px;border:1px solid #cbd5e1;border-radius:8px;background:#fff;color:#0f172a;font:600 12px "Segoe UI",Arial,sans-serif;cursor:pointer}',
    '.link:disabled{opacity:.6;cursor:default}',
    '.sub.warn{color:#b45309}',
    '.ver{font-weight:500;font-size:11px;color:#94a3b8;margin-left:6px}',
    '.panel.down{bottom:auto;top:0}',
    '.tip{display:none;position:absolute;left:0;top:0;background:#0f172a;color:#fff;font:11px/1.6 "Segoe UI",Arial,sans-serif;padding:8px 10px;border-radius:6px;white-space:pre;box-shadow:0 4px 12px rgba(0,0,0,.25);pointer-events:none}'
  ].join('\n');
  var DOT_CSS = '@keyframes uclPulse{0%{opacity:.35}50%{opacity:1}100%{opacity:.35}}#ucl-head-dot.busy{animation:uclPulse 1.1s ease-in-out infinite}';
  var DOT_COLORS = { ok: '#22c55e', warn: '#f59e0b', off: '#ef4444', busy: '#9ca3af' };

  function el(tag, cls, text) { var e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; }
  function connected() { return typeof window.__uclSend === 'function'; }
  function send(obj) { if (!connected()) return false; try { window.__uclSend(JSON.stringify(obj)); return true; } catch (e) { return false; } }
  function findAnchor() {
    var lo = document.querySelector('header button[aria-label="Logout"], [data-testid="atlas-header-logout"]');
    var box = lo && lo.parentElement;
    if (!box) return null;
    var spans = box.querySelectorAll('span'), sp = null;
    for (var i = 0; i < spans.length; i++) { if (spans[i].id !== 'ucl-head-dot' && /@almosafer\.com$/i.test(spans[i].textContent.trim())) { sp = spans[i]; break; } }
    return sp ? { box: box, span: sp, email: sp.textContent.trim() } : null;
  }
  function findEmail() { var a = findAnchor(); return a ? a.email : null; }
  function hello() {
    var em = findEmail();
    if (!em || window.__UCL_HELLO__ === em) return;
    if (send({ action: 'hello', email: em })) window.__UCL_HELLO__ = em;
  }
  function fmtTime(iso) {
    try { var d = new Date(iso); if (isNaN(d.getTime())) return ''; return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); } catch (e) { return ''; }
  }
  function statusLine(st) {
    if (!connected()) return ['off', 'Not running - start Atlas Tools on your PC'];
    if (window.__UCL_SYNCING__) return ['ok', 'Syncing your tools...'];
    var sy = st.sync || {};
    switch (sy.status) {
      case 'ok': return ['ok', 'Connected \u00b7 tools synced ' + fmtTime(sy.at)];
      case 'offline': return ['warn', 'Server not reachable \u00b7 using saved tools'];
      case 'inactive': return ['off', 'Your account is deactivated for Atlas Tools'];
      case 'not_found': return ['off', 'Your account is not registered for Atlas Tools'];
      case 'no_tools': return ['warn', 'Connected \u00b7 no tools are assigned to you'];
      case 'no-email': return ['warn', 'Connected \u00b7 detecting your Atlas account...'];
      default: return ['ok', 'Connected'];
    }
  }

  function ensureRoot() {
    var host = document.getElementById('ucl-panel-host');
    if (host && host.shadowRoot) return host.shadowRoot;
    host = document.createElement('div');
    host.id = 'ucl-panel-host';
    host.style.cssText = 'position:fixed;left:14px;bottom:14px;z-index:2147483000;';
    var root = host.attachShadow({ mode: 'open' });
    var st = document.createElement('style'); st.textContent = CSS; root.appendChild(st);
    var btn = el('button', 'pill'); btn.id = 'pill'; root.appendChild(btn);
    var panel = el('div', 'panel'); panel.id = 'panel'; root.appendChild(panel);
    var tip = el('div', 'tip'); tip.id = 'tip'; root.appendChild(tip);
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      togglePanel();
    });
    var onMove = function () { if (panel.style.display === 'block' || tip.style.display === 'block') place(); };
    window.addEventListener('scroll', onMove, true);
    window.addEventListener('resize', onMove);
    panel.addEventListener('click', function (e) { e.stopPropagation(); });
    document.addEventListener('click', function () {
      panel.style.display = 'none';
      try { sessionStorage.setItem(OPEN_KEY, '0'); } catch (er) {}
    });
    try { if (sessionStorage.getItem(OPEN_KEY) === '1') panel.style.display = 'block'; } catch (er) {}
    document.body.appendChild(host);
    return root;
  }

  function togglePanel() {
    var root = ensureRoot(), panel = root.getElementById('panel');
    var open = panel.style.display !== 'block';
    panel.style.display = open ? 'block' : 'none';
    root.getElementById('tip').style.display = 'none';
    try { sessionStorage.setItem(OPEN_KEY, open ? '1' : '0'); } catch (er) {}
    place();
  }
  // Header mode: panel opens under the dot next to the email; otherwise the
  // bottom-left "Tools" button is used (login page, or header not found yet).
  function place() {
    var host = document.getElementById('ucl-panel-host');
    if (!host || !host.shadowRoot) return;
    var root = host.shadowRoot, panel = root.getElementById('panel'), btn = root.getElementById('pill');
    var dot = document.getElementById('ucl-head-dot');
    if (dot && dot.isConnected) {
      var r = dot.getBoundingClientRect();
      var w = 310, left = Math.max(8, Math.min(r.left - 12, window.innerWidth - w - 12));
      host.style.left = left + 'px'; host.style.top = (r.bottom + 10) + 'px'; host.style.bottom = 'auto';
      panel.classList.add('down');
      btn.style.display = 'none';
    } else {
      host.style.left = '14px'; host.style.top = 'auto'; host.style.bottom = '14px';
      panel.classList.remove('down');
      btn.style.display = '';
    }
  }
  function ensureDot(line, st, onCount) {
    var a = findAnchor();
    var dot = document.getElementById('ucl-head-dot');
    if (!a) { if (dot && !dot.isConnected) dot = null; return dot; }
    if (!document.getElementById('ucl-head-dot-style') && document.head) {
      var ds = document.createElement('style'); ds.id = 'ucl-head-dot-style'; ds.textContent = DOT_CSS; document.head.appendChild(ds);
    }
    if (!dot || dot.parentElement !== a.box) {
      if (dot) dot.remove();
      dot = document.createElement('span');
      dot.id = 'ucl-head-dot';
      dot.setAttribute('role', 'button');
      dot.style.cssText = 'display:inline-block;width:8px;height:8px;border-radius:50%;margin-right:8px;cursor:pointer;flex-shrink:0;vertical-align:middle;transition:background-color .25s ease;';
      dot.addEventListener('click', function (e) { e.preventDefault(); e.stopPropagation(); togglePanel(); });
      dot.addEventListener('mouseenter', function () {
        var root = ensureRoot();
        if (root.getElementById('panel').style.display === 'block') return;
        root.getElementById('tip').style.display = 'block'; place();
      });
      dot.addEventListener('mouseleave', function () { ensureRoot().getElementById('tip').style.display = 'none'; });
      a.box.insertBefore(dot, a.span);
    }
    var kind = window.__UCL_SYNCING__ ? 'busy' : line[0];
    dot.className = kind === 'busy' ? 'busy' : '';
    dot.style.background = DOT_COLORS[kind] || DOT_COLORS.ok;
    var tipText = 'Atlas Tools v' + (st.version || '?') + '\n' + line[1] + '\n' + a.email + '\n' + onCount + ' tool(s) on \u00b7 click to manage';
    ensureRoot().getElementById('tip').textContent = tipText;
    return dot;
  }

  function render() {
    if (!document.body) return;
    var root = ensureRoot();
    var btn = root.getElementById('pill'), panel = root.getElementById('panel');
    var st = window.__UCL_STATE__ || { tools: [] };
    var tools = st.tools || [];
    hello();
    if (window.__UCL_SYNCING__) {
      var sy0 = st.sync || {};
      if (sy0.n !== window.__UCL_SYNCING__.n || Date.now() - window.__UCL_SYNCING__.t > 30000) window.__UCL_SYNCING__ = null;
    }
    var run = window.__UCL_TOOLS__ || {};

    Object.keys(pending).forEach(function (k) {
      var t = tools.filter(function (x) { return x.key === k; })[0];
      if (t && t.on === pending[k].on) { delete pending[k]; }
      else if (Date.now() - pending[k].at > 10000) { delete pending[k]; window.__UCL_MSG__ = 'Atlas Tools did not respond. Is it running?'; }
    });

    var onCount = tools.filter(function (t) { return t.on; }).length;
    btn.textContent = '';
    btn.appendChild(el('span', 'dot ' + (connected() ? 'ok' : 'off')));
    btn.appendChild(document.createTextNode('Tools' + (onCount ? ' \u00b7 ' + onCount + ' on' : '')));

    panel.textContent = '';
    var head = el('div', 'head');
    var ttl = el('div', 'title', 'Atlas Tools');
    if (st.version) ttl.appendChild(el('span', 'ver', 'v' + st.version));
    head.appendChild(ttl);
    var line = statusLine(st);
    head.appendChild(el('div', 'sub ' + line[0], line[1]));
    panel.appendChild(head);

    var list = el('div', 'list');
    if (!tools.length) list.appendChild(el('div', 'empty', 'No tools yet. They appear here after your tools are synced.'));
    var needReload = false;
    tools.forEach(function (t) {
      var row = el('label', 'row');
      var sw = document.createElement('input'); sw.type = 'checkbox'; sw.className = 'sw';
      var p = pending[t.key];
      sw.checked = p ? p.on : !!t.on;
      sw.disabled = !!p || !connected();
      sw.addEventListener('change', function () {
        var want = sw.checked;
        if (send({ action: 'toggle', key: t.key, on: want })) {
          pending[t.key] = { on: want, at: Date.now() };
          setTimeout(function () { if (window.__UCL_RENDER__) window.__UCL_RENDER__(); }, 10500);
        } else {
          window.__UCL_MSG__ = 'Atlas Tools is not running, so tools cannot be changed.';
        }
        render();
      });
      var txt = el('div', 'txt');
      txt.appendChild(el('div', 'name', t.name || t.key));
      if (t.desc) txt.appendChild(el('div', 'desc', t.desc));
      var chip = null;
      if (p) chip = el('span', 'chip busy', 'Applying...');
      else if (t.on && run[t.key]) chip = el('span', 'chip on', 'Running');
      else if (t.on) chip = el('span', 'chip idle', 'Not used on this page');
      else if (run[t.key]) { chip = el('span', 'chip warn', 'Stops after reload'); needReload = true; }
      if (chip) txt.appendChild(chip);
      row.appendChild(sw); row.appendChild(txt); list.appendChild(row);
    });
    panel.appendChild(list);

    var foot = el('div', 'foot');
    if (window.__UCL_MSG__) foot.appendChild(el('div', 'msg', window.__UCL_MSG__));
    if (needReload) {
      var rb = el('button', 'reload', 'Reload page to apply');
      rb.addEventListener('click', function () { location.reload(); });
      foot.appendChild(rb);
    }
    if (connected()) {
      var syncBtn = el('button', 'link', window.__UCL_SYNCING__ ? 'Syncing...' : 'Sync tools now');
      syncBtn.disabled = !!window.__UCL_SYNCING__;
      syncBtn.addEventListener('click', function () {
        var s0 = (window.__UCL_STATE__ || {}).sync || {};
        if (send({ action: 'sync' })) {
          window.__UCL_SYNCING__ = { n: s0.n, t: Date.now() };
          setTimeout(function () { if (window.__UCL_RENDER__) window.__UCL_RENDER__(); }, 30500);
        }
        render();
      });
      foot.appendChild(syncBtn);
    }
    if (foot.childNodes.length) panel.appendChild(foot);
    ensureDot(line, st, onCount);
    place();
  }

  window.__UCL_RENDER__ = render;
  window.__UCL_HELLO_FN__ = hello;
  if (document.body) { render(); } else { document.addEventListener('DOMContentLoaded', function () { window.__UCL_RENDER__(); }); }
  if (!window.__UCL_PANEL_TIMER__) {
    window.__UCL_PANEL_TIMER__ = setInterval(function () {
      if (!document.body || !window.__UCL_RENDER__) return;
      var d = document.getElementById('ucl-head-dot'), h = document.getElementById('ucl-panel-host');
      var pill = h && h.shadowRoot && h.shadowRoot.getElementById('pill');
      if (!h || ((!d || !d.isConnected) && (findAnchor() || (pill && pill.style.display === 'none')))) window.__UCL_RENDER__();
      else if (window.__UCL_HELLO_FN__) window.__UCL_HELLO_FN__();
    }, 700);
  }
})();
'@

function New-ToolBundle {
    $ticked = @($Global:UclSettings.checked)
    $cloud  = @($Global:UclSettings.cloud)
    $stateItems = New-Object System.Collections.Generic.List[string]
    $pushes = New-Object System.Text.StringBuilder

    # Read every tool once; a manual copy of a synced tool is skipped (no double loading)
    $infos = @()
    foreach ($f in @(Get-ToolFiles)) {
        # A saved tool that cannot be opened (damaged, or from another Windows account) is skipped; the next sync replaces it
        try { $code = Read-ToolCode $f } catch { $Global:UclLastError = 'Could not open saved tool ' + $f.Name + ' (it is replaced at the next sync)'; continue }
        $infos += [pscustomobject]@{ File = $f; Code = $code; Hdr = (Get-ToolHeader -Code $code); Norm = (($code -replace "`r", '').Trim()); IsCloud = ($cloud -contains $f.Name) }
    }
    $cloudNames = @($infos | Where-Object { $_.IsCloud -and $_.Hdr.Name } | ForEach-Object { [string]$_.Hdr.Name })
    $cloudCodes = @($infos | Where-Object { $_.IsCloud } | ForEach-Object { $_.Norm })
    $Global:UclSkippedDuplicates = @()

    foreach ($info in $infos) {
        $f = $info.File; $code = $info.Code; $hdr = $info.Hdr
        if (-not $info.IsCloud -and (($hdr.Name -and $cloudNames -contains [string]$hdr.Name) -or ($cloudCodes -contains $info.Norm))) {
            $Global:UclSkippedDuplicates += $f.Name
            continue
        }
        $on = $ticked -contains $f.Name
        $display = if ($hdr.Name) { [string]$hdr.Name } else { [string]$f.BaseName }
        $desc = [string]$hdr.Description
        if (-not $desc -and $Global:UclCloudDesc -and $Global:UclCloudDesc.ContainsKey($f.Name)) { $desc = [string]$Global:UclCloudDesc[$f.Name] }
        $stateItems.Add('{"key":' + ([string]$f.Name | ConvertTo-Json -Compress) +
            ',"name":' + ($display | ConvertTo-Json -Compress) +
            ',"desc":' + ($desc | ConvertTo-Json -Compress) +
            ',"on":' + $(if ($on) { 'true' } else { 'false' }) + '}')
        if ($on) {
            $regexes = @($hdr.Matches | ForEach-Object { (Convert-MatchToRegex $_) | ConvertTo-Json -Compress })
            [void]$pushes.Append("  tools.push({ key: " + ($f.Name | ConvertTo-Json -Compress) +
                ", runAt: " + ($hdr.RunAt | ConvertTo-Json -Compress) +
                ", match: [" + ($regexes -join ', ') + "]" +
                ", run: function (GM_addStyle, GM_setValue, GM_getValue, GM_deleteValue, GM_listValues, GM_setClipboard, GM_openInTab, GM_addValueChangeListener, GM_removeValueChangeListener, GM_registerMenuCommand, GM_notification, GM_xmlhttpRequest, GM, unsafeWindow) {`n")
            [void]$pushes.Append($code)
            [void]$pushes.Append("`n  } });`n")
        }
    }
    $sy = $Global:UclSync
    $syStatus = if ($sy) { [string]$sy.status } else { '' }
    $syN = if ($sy) { [int]$sy.n } else { 0 }
    $syMsg = if ($sy) { [string]$sy.message } else { '' }
    $syncJson = '{"status":' + ($syStatus | ConvertTo-Json -Compress) +
        ',"at":' + ([string]$Global:UclSettings.lastSync | ConvertTo-Json -Compress) +
        ',"n":' + $syN + ',"message":' + ($syMsg | ConvertTo-Json -Compress) + '}'
    $stateJson = '{"version":' + ($LauncherVersion | ConvertTo-Json -Compress) + ',"tools":[' + ($stateItems -join ',') + '],"sync":' + $syncJson + '}'
    $sb = New-Object System.Text.StringBuilder
    [void]$sb.Append($UclBundleHead.Replace("'__UCL_TOKEN__'", ([string]$Global:UclSettings.token | ConvertTo-Json -Compress)))
    [void]$sb.Append("`n  window.__UCL_STATE__ = " + $stateJson + ";`n")
    [void]$sb.Append($pushes.ToString())
    [void]$sb.Append($UclBundleTail)
    return $sb.ToString()
}

# ---------------------------------------------------------------------
#  ENGINE: one connection per WORK Chrome tab
# ---------------------------------------------------------------------
# ---------------------------------------------------------------------
#  SHARED TOOL STORAGE (what Tampermonkey's GM_setValue used to do)
#  One store for all websites, saved under gm-store\<tool>\<hash>.json
# ---------------------------------------------------------------------
function Get-GmToolStore {
    param([string]$Tool)
    if ($null -eq $Global:UclGm) { $Global:UclGm = New-Object 'System.Collections.Generic.Dictionary[string,object]' }
    if (-not $Global:UclGm.ContainsKey($Tool)) {
        $Global:UclGm[$Tool] = New-Object 'System.Collections.Generic.Dictionary[string,string]'
    }
    return $Global:UclGm[$Tool]
}

function Get-GmStampStore {
    param([string]$Tool)
    if ($null -eq $Global:UclGmStamp) { $Global:UclGmStamp = New-Object 'System.Collections.Generic.Dictionary[string,object]' }
    if (-not $Global:UclGmStamp.ContainsKey($Tool)) {
        $Global:UclGmStamp[$Tool] = New-Object 'System.Collections.Generic.Dictionary[string,long]'
    }
    return $Global:UclGmStamp[$Tool]
}

function Get-GmTombStore {
    param([string]$Tool)
    if ($null -eq $Global:UclGmTomb) { $Global:UclGmTomb = New-Object 'System.Collections.Generic.Dictionary[string,object]' }
    if (-not $Global:UclGmTomb.ContainsKey($Tool)) {
        $Global:UclGmTomb[$Tool] = New-Object 'System.Collections.Generic.Dictionary[string,long]'
    }
    return $Global:UclGmTomb[$Tool]
}

function Get-NowStamp { return [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() * 1000 }

function Get-GmKeyPath {
    param([string]$Tool, [string]$Key)
    $dir = Join-Path $GmDir (($Tool -replace '[\\/:*?"<>|]', '_').TrimStart('.'))
    $sha = [System.Security.Cryptography.SHA1]::Create()
    $hex = -join ($sha.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($Key)) | ForEach-Object { $_.ToString('x2') })
    $sha.Dispose()
    return [pscustomobject]@{ Dir = $dir; File = (Join-Path $dir ($hex + '.json')) }
}

function Save-GmValue {
    param([string]$Tool, [string]$Key, $Json, [long]$Stamp = 0)
    try {
        $p = Get-GmKeyPath -Tool $Tool -Key $Key
        if (-not (Test-Path -LiteralPath $p.Dir)) { New-Item -ItemType Directory -Path $p.Dir -Force | Out-Null }
        # line 1 = tool, line 2 = key (JSON-escaped), line 3 = stamp, rest = the value
        # a deleted value is kept as a small "deleted at" record (#d:) for 7 days
        if ($null -eq $Json) { $text = (JStr $Tool) + "`n" + (JStr $Key) + "`n#d:" + $Stamp + "`n" }
        else { $text = (JStr $Tool) + "`n" + (JStr $Key) + "`n#s:" + $Stamp + "`n" + [string]$Json }
        [System.IO.File]::WriteAllText($p.File, $text, (New-Object System.Text.UTF8Encoding($false)))
    } catch { $Global:UclLastError = 'Could not save tool data: ' + $_.Exception.Message }
}

function Read-GmStore {
    $Global:UclGm = New-Object 'System.Collections.Generic.Dictionary[string,object]'
    $Global:UclGmStamp = New-Object 'System.Collections.Generic.Dictionary[string,object]'
    $Global:UclGmTomb = New-Object 'System.Collections.Generic.Dictionary[string,object]'
    if (-not (Test-Path -LiteralPath $GmDir)) { return }
    foreach ($f in @(Get-ChildItem -LiteralPath $GmDir -Recurse -Filter '*.json' -File -ErrorAction SilentlyContinue)) {
        try {
            $text = [System.IO.File]::ReadAllText($f.FullName, [System.Text.Encoding]::UTF8)
            $a = $text.IndexOf("`n"); $b = $text.IndexOf("`n", $a + 1)
            if ($a -lt 0 -or $b -lt 0) { continue }
            $tool = [string]($text.Substring(0, $a) | ConvertFrom-Json)
            $key  = [string]($text.Substring($a + 1, $b - $a - 1) | ConvertFrom-Json)
            $rest = $text.Substring($b + 1)
            if ($rest.StartsWith('#d:')) {
                $c = $rest.IndexOf("`n")
                $ds = [long]$rest.Substring(3, $c - 3)
                if (((Get-NowStamp) - $ds) -gt 604800000000) { Remove-Item -LiteralPath $f.FullName -Force -ErrorAction SilentlyContinue; continue }
                (Get-GmTombStore $tool)[$key] = $ds
                (Get-GmStampStore $tool)[$key] = $ds
                continue
            }
            $stamp = [long]1
            if ($rest.StartsWith('#s:')) {
                $c = $rest.IndexOf("`n")
                $stamp = [long]$rest.Substring(3, $c - 3)
                $rest = $rest.Substring($c + 1)
            }
            (Get-GmToolStore $tool)[$key] = $rest
            (Get-GmStampStore $tool)[$key] = $stamp
        } catch {}
    }
}

# Small values go into every page up front; big ones (images) are sent on request
function New-GmStoreScript {
    $parts = New-Object System.Collections.Generic.List[string]
    foreach ($tool in @($Global:UclGm.Keys)) {
        $d = $Global:UclGm[$tool]
        $st = Get-GmStampStore $tool
        $v = New-Object System.Collections.Generic.List[string]
        $b = New-Object System.Collections.Generic.List[string]
        foreach ($k in @($d.Keys)) {
            $j = $d[$k]
            $s0 = [long]0
            [void]$st.TryGetValue($k, [ref]$s0)
            if ($j.Length -gt $GmBigChars) { $b.Add((JStr $k) + ':' + $s0) }
            else { $v.Add((JStr $k) + ':[' + (JStr $j) + ',' + $s0 + ']') }
        }
        $parts.Add((JStr $tool) + ':{"v":{' + ($v -join ',') + '},"b":{' + ($b -join ',') + '}}')
    }
    return 'window.__UCL_GM_SNAPSHOT__ = {"at":' + (Get-NowStamp) + ',"tools":{' + ($parts -join ',') + '}};'
}


# New pages must start with the latest values: replace the registered snapshot on every tab

# ---------------------------------------------------------------------
#  DOWNLOADS FOR TOOLS (what GM_xmlhttpRequest used to do)
#  Only GET/HEAD, only public internet addresses, max 25 MB.
# ---------------------------------------------------------------------
function Test-PublicAddress {
    param([System.Net.IPAddress]$A)
    if ([System.Net.IPAddress]::IsLoopback($A)) { return $false }
    if ($A.AddressFamily -eq [System.Net.Sockets.AddressFamily]::InterNetworkV6) {
        if ($A.IsIPv4MappedToIPv6) { return (Test-PublicAddress $A.MapToIPv4()) }
        if ($A.IsIPv6LinkLocal -or $A.IsIPv6SiteLocal -or $A.IsIPv6Multicast) { return $false }
        if ($A.Equals([System.Net.IPAddress]::IPv6Any)) { return $false }
        $b6 = $A.GetAddressBytes()
        if (($b6[0] -band 0xfe) -eq 0xfc) { return $false }
        return $true
    }
    $b = $A.GetAddressBytes()
    if ($b[0] -eq 0 -or $b[0] -eq 10 -or $b[0] -eq 127 -or $b[0] -ge 224) { return $false }
    if ($b[0] -eq 169 -and $b[1] -eq 254) { return $false }
    if ($b[0] -eq 172 -and $b[1] -ge 16 -and $b[1] -le 31) { return $false }
    if ($b[0] -eq 192 -and $b[1] -eq 168) { return $false }
    if ($b[0] -eq 100 -and $b[1] -ge 64 -and $b[1] -le 127) { return $false }
    return $true
}

function Test-AllowedUrl {
    param([Uri]$U)
    if ($U.Scheme -ne 'http' -and $U.Scheme -ne 'https') { return $false }
    $hostName = $U.DnsSafeHost
    $ip = $null
    if ([System.Net.IPAddress]::TryParse($hostName, [ref]$ip)) { return (Test-PublicAddress $ip) }
    if ($hostName -match '(^|\.)localhost$' -or $hostName -notmatch '\.') { return $false }
    $addrs = @()
    try { $addrs = @([System.Net.Dns]::GetHostAddresses($hostName)) } catch {}
    if ($addrs.Count -eq 0) {
        # Name cannot be looked up here: allow only when it goes out through the company web proxy
        try { $px = [System.Net.WebRequest]::DefaultWebProxy; if ($px -and -not $px.IsBypassed($U)) { return $true } } catch {}
        return $false
    }
    foreach ($a in $addrs) { if (-not (Test-PublicAddress $a)) { return $false } }
    return $true
}

function Initialize-Http {
    try { Add-Type -AssemblyName System.Net.Http } catch {}
    try { [System.Net.ServicePointManager]::DefaultConnectionLimit = 16 } catch {}
    $h = New-Object System.Net.Http.HttpClientHandler
    $h.AllowAutoRedirect = $false
    $h.UseCookies = $false
    $h.AutomaticDecompression = [System.Net.DecompressionMethods]::GZip -bor [System.Net.DecompressionMethods]::Deflate
    $c = New-Object System.Net.Http.HttpClient($h)
    $c.MaxResponseContentBufferSize = $MaxXhrBytes
    $c.Timeout = [TimeSpan]::FromSeconds(120)
    [void]$c.DefaultRequestHeaders.TryAddWithoutValidation('User-Agent', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0 Safari/537.36')
    $Global:UclHttp = $c
    $Global:UclXhrJobs = New-Object System.Collections.ArrayList
    $Global:UclHostOk = @{}
    $Global:UclXhrStats = [pscustomobject]@{ Done = 0; Failed = 0; LastMs = 0; LastError = '' }
}

# The safety check is remembered per website for 10 minutes
function Test-AllowedUrlCached {
    param([Uri]$U)
    $k = $U.Scheme + '://' + $U.DnsSafeHost
    $c = $Global:UclHostOk[$k]
    if ($c -and ((Get-Date) - $c.At).TotalMinutes -lt 10) { return $c.Ok }
    $ok = Test-AllowedUrl $U
    $Global:UclHostOk[$k] = [pscustomobject]@{ Ok = $ok; At = (Get-Date) }
    return $ok
}

function Send-XhrResult {
    param($Job, $Res)
    $ms = [int]((Get-Date) - $Job.Started).TotalMilliseconds
    if ($Res.error) { $Global:UclXhrStats.Failed++; $Global:UclXhrStats.LastError = [string]$Res.error } else { $Global:UclXhrStats.Done++ }
    $Global:UclXhrStats.LastMs = $ms
    $s = $Global:UclSessions[$Job.Sid]
    if (-not $s) { return }
    Send-SessionEval -Session $s -Expression ('window.__UCL_XHR_DONE__ && window.__UCL_XHR_DONE__(' + [int]$Job.Id + ',' + (ConvertTo-XhrResultJson $Res) + ')')
}

# Start (or continue after a redirect) one download, without waiting for it
function Start-XhrHop {
    param($Job)
    if ($Job.Hop -gt 5) { $Job.Done = $true; Send-XhrResult $Job @{ error = 'Too many redirects' }; return }
    if (-not (Test-AllowedUrlCached $Job.Uri)) { $Job.Done = $true; Send-XhrResult $Job @{ error = ('Blocked address: ' + $Job.Uri.Host) }; return }
    try {
        $msg = New-Object System.Net.Http.HttpRequestMessage((New-Object System.Net.Http.HttpMethod($Job.Method)), $Job.Uri)
        foreach ($hn in @($Job.Headers.Keys)) {
            $hv = [string]$Job.Headers[$hn]
            if ($hn -match '^(?i)referer$') { try { $msg.Headers.Referrer = [Uri]$hv } catch {} }
            elseif ($hn -match '^(?i)(accept|accept-language|cache-control|pragma)$') { [void]$msg.Headers.TryAddWithoutValidation($hn, $hv) }
        }
        $Job.Cts = New-Object System.Threading.CancellationTokenSource($Job.Timeout)
        $Job.Task = $Global:UclHttp.SendAsync($msg, [System.Net.Http.HttpCompletionOption]::ResponseContentRead, $Job.Cts.Token)
    } catch {
        $Job.Done = $true
        Send-XhrResult $Job @{ error = $_.Exception.GetBaseException().Message }
    }
}

function Start-GmXhr {
    param($R, $Sid)
    $job = [pscustomobject]@{ Sid = $Sid; Id = [int]$R.id; Method = ([string]$R.method).ToUpperInvariant(); Uri = $null; Headers = @{}; Hop = 0; Timeout = 30000; Task = $null; Cts = $null; Done = $false; Started = (Get-Date) }
    if ($job.Method -ne 'GET' -and $job.Method -ne 'HEAD') { Send-XhrResult $job @{ error = 'Only downloads (GET) are allowed' }; return }
    $u = $null
    if (-not [Uri]::TryCreate([string]$R.url, [UriKind]::Absolute, [ref]$u)) { Send-XhrResult $job @{ error = 'Bad address' }; return }
    $job.Uri = $u
    try { if ([int]$R.timeout -gt 0 -and [int]$R.timeout -le 60000) { $job.Timeout = [int]$R.timeout } } catch {}
    if ($R.headers) { foreach ($p in $R.headers.PSObject.Properties) { $job.Headers[[string]$p.Name] = [string]$p.Value } }
    Start-XhrHop $job
    if (-not $job.Done) { [void]$Global:UclXhrJobs.Add($job) }
}

# Called on every engine tick: hand finished downloads back to the page
function Update-XhrJobs {
    if (-not $Global:UclXhrJobs -or $Global:UclXhrJobs.Count -eq 0) { return }
    foreach ($job in $Global:UclXhrJobs.ToArray()) {
        if (-not $job.Task -or -not $job.Task.IsCompleted) { continue }
        $res = $null
        if ($job.Task.IsCanceled) {
            $res = @{ error = 'Download timed out'; timeout = $true }
        } elseif ($job.Task.IsFaulted) {
            if ($job.Cts -and $job.Cts.IsCancellationRequested) { $res = @{ error = 'Download timed out'; timeout = $true } }
            else {
                $m = $job.Task.Exception.GetBaseException().Message
                if ($m -match 'buffer') { $m = 'File is larger than 25 MB' }
                $res = @{ error = $m }
            }
        } else {
            $resp = $job.Task.Result
            $code = [int]$resp.StatusCode
            $loc = $resp.Headers.Location
            if ($code -ge 300 -and $code -lt 400 -and $loc) {
                $next = $null
                if ($loc.IsAbsoluteUri) { $next = $loc } else { [void][Uri]::TryCreate($job.Uri, $loc.OriginalString, [ref]$next) }
                try { $resp.Dispose(); $job.Cts.Dispose() } catch {}
                if ($next) {
                    $job.Uri = $next
                    $job.Hop++
                    Start-XhrHop $job
                    if ($job.Done) { [void]$Global:UclXhrJobs.Remove($job) }
                    continue
                }
                $res = @{ error = 'Bad redirect' }
            } else {
                try {
                    $bytes = $resp.Content.ReadAsByteArrayAsync().Result
                    $hdr = New-Object System.Collections.Generic.List[string]
                    foreach ($h in $resp.Headers) { $hdr.Add($h.Key + ': ' + (@($h.Value) -join ', ')) }
                    foreach ($h in $resp.Content.Headers) { $hdr.Add($h.Key + ': ' + (@($h.Value) -join ', ')) }
                    $ctype = if ($resp.Content.Headers.ContentType) { $resp.Content.Headers.ContentType.ToString() } else { '' }
                    $res = @{ status = $code; statusText = [string]$resp.ReasonPhrase; finalUrl = $job.Uri.AbsoluteUri; headers = ($hdr -join "`r`n"); type = $ctype; b64 = [Convert]::ToBase64String($bytes) }
                } catch { $res = @{ error = $_.Exception.GetBaseException().Message } }
                try { $resp.Dispose() } catch {}
            }
        }
        try { if ($job.Cts) { $job.Cts.Dispose() } } catch {}
        [void]$Global:UclXhrJobs.Remove($job)
        Send-XhrResult $job $res
    }
}


function ConvertTo-XhrResultJson {
    param($Res)
    if ($Res.error) {
        return '{"error":' + (JStr ([string]$Res.error)) + ',"timeout":' + $(if ($Res.timeout) { 'true' } else { 'false' }) + '}'
    }
    return '{"status":' + [int]$Res.status +
        ',"statusText":' + (JStr ([string]$Res.statusText)) +
        ',"finalUrl":' + (JStr ([string]$Res.finalUrl)) +
        ',"headers":' + (JStr ([string]$Res.headers)) +
        ',"type":' + (JStr ([string]$Res.type)) +
        ',"b64":"' + $Res.b64 + '"}'
}

# Requests from tools (storage, downloads); only accepted with the launcher's private key
function Send-ToOtherTabs {
    param($Sid, [string]$Expression, [switch]$OnlyVisible, [switch]$OnlyHidden)
    $params = $null
    foreach ($id in @($Global:UclSessions.Keys)) {
        if ($id -eq $Sid) { continue }
        $s = $Global:UclSessions[$id]
        if (-not $s -or -not $s.SessionId) { continue }
        if ($OnlyVisible -and -not $s.Visible) { continue }
        if ($OnlyHidden -and $s.Visible) { continue }
        if (-not $params) { $params = '{"expression":' + (JStr $Expression) + '}' }
        [void](Send-Cdp -SessionId $s.SessionId -Method 'Runtime.evaluate' -ParamsJson $params)
    }
}

# Requests from tools (storage, downloads); only accepted with the launcher's private key
function Invoke-ToolRequest {
    param($R, $Sid)
    $tool = [string]$R.tool
    if (-not $tool -or $tool -match '[\\/]') { return }
    $sender = if ($Sid) { $Global:UclSessions[$Sid] } else { $null }
    switch ([string]$R.action) {
        'gm_set' {
            $k = [string]$R.key
            $j = [string]$R.v
            $stamp = [long]0
            try { $stamp = [long]$R.s } catch {}
            if ($stamp -le 0) { $stamp = Get-NowStamp }
            $st = Get-GmStampStore $tool; $tb = Get-GmTombStore $tool
            $cur = [long]0; [void]$st.TryGetValue($k, [ref]$cur)
            $gone = [long]0; [void]$tb.TryGetValue($k, [ref]$gone)
            if ($stamp -le $cur -or $stamp -le $gone) { return }
            (Get-GmToolStore $tool)[$k] = $j
            $st[$k] = $stamp
            if ($tb.ContainsKey($k)) { [void]$tb.Remove($k) }
            $isBig = $j.Length -gt $(if ($GmSendChars) { $GmSendChars } else { 65536 })
            $full = 'window.__UCL_GM_APPLY__&&window.__UCL_GM_APPLY__(' + (JStr $tool) + ',' + (JStr $k) + ',' + (JStr $j) + ',' + $stamp + ',false)'
            if (-not $isBig) { Send-ToOtherTabs $Sid $full }
            else {
                $notice = 'window.__UCL_GM_APPLY__&&window.__UCL_GM_APPLY__(' + (JStr $tool) + ',' + (JStr $k) + ',null,' + $stamp + ',true)'
                Send-ToOtherTabs $Sid $full -OnlyVisible
                Send-ToOtherTabs $Sid $notice -OnlyHidden
            }
            Save-GmValue -Tool $tool -Key $k -Json $j -Stamp $stamp
            $Global:UclGmDirty = $true
            Set-StoreChanged
        }
        'gm_del' {
            $k = [string]$R.key
            $stamp = [long]0
            try { $stamp = [long]$R.s } catch {}
            if ($stamp -le 0) { $stamp = Get-NowStamp }
            $st = Get-GmStampStore $tool; $tb = Get-GmTombStore $tool
            $cur = [long]0; [void]$st.TryGetValue($k, [ref]$cur)
            if ($stamp -le $cur) { return }
            $store = Get-GmToolStore $tool
            if ($store.ContainsKey($k)) { [void]$store.Remove($k) }
            $st[$k] = $stamp
            $tb[$k] = $stamp
            Send-ToOtherTabs $Sid ('window.__UCL_GM_APPLY__&&window.__UCL_GM_APPLY__(' + (JStr $tool) + ',' + (JStr $k) + ',null,' + $stamp + ',false)')
            Save-GmValue -Tool $tool -Key $k -Json $null -Stamp $stamp
            $Global:UclGmDirty = $true
            Set-StoreChanged
        }
        'gm_need' {
            # Send each requested item separately, smallest first (the list before the big images)
            if (-not $sender) { return }
            $store = Get-GmToolStore $tool; $st = Get-GmStampStore $tool
            $keys = @(@($R.keys) | ForEach-Object { [string]$_ } | Where-Object { $store.ContainsKey($_) } | Sort-Object { $store[$_].Length })
            foreach ($k in $keys) {
                $s0 = [long]0; [void]$st.TryGetValue($k, [ref]$s0)
                $ck = $tool + '|' + $k + '|' + $s0
                if (-not $Global:UclEncCache) { $Global:UclEncCache = @{} }
                if (-not $Global:UclEncCache.ContainsKey($ck)) {
                    if ($Global:UclEncCache.Count -gt 60) { $Global:UclEncCache = @{} }
                    $Global:UclEncCache[$ck] = JStr ($store[$k])
                }
                Send-SessionEval -Session $sender -Expression ('window.__UCL_GM_FILL__&&window.__UCL_GM_FILL__(' + (JStr $tool) + ',{' + (JStr $k) + ':[' + $Global:UclEncCache[$ck] + ',' + $s0 + ']})')
            }
        }
        'gm_catchup' {
            # A page that just started: send anything newer than the copy it started with
            if (-not $sender) { return }
            $since = [long]0
            try { $since = [long]$R.since } catch {}
            $store = Get-GmToolStore $tool; $st = Get-GmStampStore $tool; $tb = Get-GmTombStore $tool
            $rows = New-Object System.Collections.Generic.List[string]
            foreach ($k in @($st.Keys)) {
                $s0 = $st[$k]
                if ($s0 -le $since) { continue }
                if ($store.ContainsKey($k)) {
                    $j = $store[$k]
                    if ($j.Length -gt $(if ($GmSendChars) { $GmSendChars } else { 65536 })) { $rows.Add('[' + (JStr $k) + ',null,' + $s0 + ',true]') }
                    else { $rows.Add('[' + (JStr $k) + ',' + (JStr $j) + ',' + $s0 + ',false]') }
                } elseif ($tb.ContainsKey($k)) {
                    $rows.Add('[' + (JStr $k) + ',null,' + $s0 + ',false]')
                }
            }
            if ($rows.Count) { Send-SessionEval -Session $sender -Expression ('window.__UCL_GM_BATCH__&&window.__UCL_GM_BATCH__(' + (JStr $tool) + ',[' + ($rows -join ',') + '])') }
        }
        'xhr' {
            if (-not $sender) { return }
            Start-GmXhr -R $R -Sid $Sid
        }
        'vis' {
            if ($sender) { $sender.Visible = [bool]$R.visible }
        }
    }
}





# Read everything Chrome sent; collect requests from the in-page panel

# Connect to new tabs, forget closed ones

# Ticks changed: re-register the new bundle on every tab

# Apply switch changes made in the in-page panel
# ---------------------------------------------------------------------
#  ENGINE (v0.13): ONE connection to the whole WORK Chrome.
#  Chrome tells us right away when a tab opens, navigates or closes,
#  and we never wait for a tab to answer.
# ---------------------------------------------------------------------
function Send-WsJson {
    param($Ws, [string]$Json)
    $bytes = [System.Text.Encoding]::UTF8.GetBytes($Json)
    $seg = New-Object System.ArraySegment[byte] -ArgumentList (,$bytes)
    $t = $Ws.SendAsync($seg, [System.Net.WebSockets.WebSocketMessageType]::Text, $true, [System.Threading.CancellationToken]::None)
    if (-not $t.Wait(10000)) { throw 'send timeout' }
}

# Send one command (to Chrome, or to one tab when SessionId is given); returns its id
function Send-Cdp {
    param([string]$SessionId = '', [string]$Method, [string]$ParamsJson = '{}', [string]$Purpose = '', $Session = $null, [string]$TargetId = '')
    $b = $Global:UclBrowser
    if (-not $b) { return 0 }
    $b.NextId++
    $id = $b.NextId
    if ($Purpose) { $b.Expect[[string]$id] = [pscustomobject]@{ Purpose = $Purpose; Session = $Session; TargetId = $TargetId } }
    $json = '{"id":' + $id + ','
    if ($SessionId) { $json += '"sessionId":' + (JStr $SessionId) + ',' }
    $json += '"method":' + (JStr $Method) + ',"params":' + $ParamsJson + '}'
    try { Send-WsJson -Ws $b.Ws -Json $json } catch { Disconnect-Browser; return 0 }
    return $id
}

function Send-SessionEval {
    param($Session, [string]$Expression)
    if (-not $Session -or -not $Session.SessionId) { return }
    [void](Send-Cdp -SessionId $Session.SessionId -Method 'Runtime.evaluate' -ParamsJson ('{"expression":' + (JStr $Expression) + '}'))
}

function Start-BrowserReceive {
    $b = $Global:UclBrowser
    $seg = New-Object System.ArraySegment[byte] -ArgumentList (,$b.Buf)
    $b.Pending = $b.Ws.ReceiveAsync($seg, [System.Threading.CancellationToken]::None)
}

function Disconnect-Browser {
    $b = $Global:UclBrowser
    $Global:UclBrowser = $null
    if ($b) { try { $b.Ws.Dispose() } catch {} }
    $Global:UclSessions = @{}
    $Global:UclSessionIds = @{}
    $Global:UclAttaching = @{}
    $Global:UclPendingExisting = @{}
    $Global:UclRechecks = New-Object System.Collections.ArrayList
    $Global:UclConnected = $false
}

# Kept for older callers (quit, settings window)
function Close-AllUclSessions { Disconnect-Browser }

function Connect-Browser {
    try {
        $ver = Get-CdpJson '/json/version'
        $url = [string]$ver.webSocketDebuggerUrl
        if ($url -notmatch '^ws://127\.0\.0\.1:9223/devtools/browser/') { throw ('Unexpected Chrome address: ' + $url) }
        $ws = New-Object System.Net.WebSockets.ClientWebSocket
        $c = $ws.ConnectAsync([Uri]$url, [System.Threading.CancellationToken]::None)
        if (-not $c.Wait(5000)) { throw 'Chrome did not accept the connection' }
        $Global:UclBrowser = [pscustomobject]@{ Ws = $ws; Buf = (New-Object byte[] 262144); Sb = (New-Object System.Text.StringBuilder); Pending = $null; NextId = 0; Expect = @{}; AutoAttachSeen = $false; ConnectedAt = (Get-Date) }
        $Global:UclPendingExisting = @{}
        $Global:UclRechecks = New-Object System.Collections.ArrayList
        $Global:UclSessions = @{}
        $Global:UclSessionIds = @{}
        $Global:UclAttaching = @{}
        $Global:UclBundleText = New-ToolBundle
        $Global:UclBundleJson = $null
        $Global:UclStoreJson = $null
        Start-BrowserReceive
        $Global:UclConnected = $true
        # Chrome now reports every tab; new tabs wait a moment until their tools are in place
        [void](Send-Cdp -Method 'Target.setDiscoverTargets' -ParamsJson '{"discover":true}')
        [void](Send-Cdp -Method 'Target.setAutoAttach' -ParamsJson '{"autoAttach":true,"waitForDebuggerOnStart":true,"flatten":true}')
        return $true
    } catch {
        Disconnect-Browser
        $Global:UclLastError = 'Chrome connection: ' + $_.Exception.GetBaseException().Message
        return $false
    }
}

function Request-Attach {
    param($Info)
    if (-not $Info -or [string]$Info.type -ne 'page') { return }
    $tid = [string]$Info.targetId
    if ($Global:UclSessions.ContainsKey($tid) -or $Global:UclAttaching.ContainsKey($tid)) { return }
    if ([string]$Info.url -match '^(devtools|chrome-extension|chrome-untrusted)://') { return }
    $Global:UclAttaching[$tid] = Get-Date
    [void](Send-Cdp -Method 'Target.attachToTarget' -ParamsJson ('{"targetId":' + (JStr $tid) + ',"flatten":true}') -Purpose 'attach' -TargetId $tid)
}

function Test-WebUrl { param([string]$Url) return ($Url -match '^https?://') }

function Get-UrlOrigin {
    param([string]$Url)
    $m = [regex]::Match($Url, '^(https?://[^/?#]+)')
    if ($m.Success) { return $m.Groups[1].Value.ToLowerInvariant() } else { return $Url }
}

# Put the tools into the page that is open right now (safe to repeat: tools never load twice)
function Get-BundleJson {
    if (-not $Global:UclBundleJson) { $Global:UclBundleJson = JStr $Global:UclBundleText }
    return $Global:UclBundleJson
}

function Get-StoreJson {
    if (-not $Global:UclStoreJson) { $Global:UclStoreJson = JStr (New-GmStoreScript) }
    return $Global:UclStoreJson
}

# Saved data changed: tabs refresh their copy the next time they start loading a page
function Set-StoreChanged {
    $Global:UclStoreJson = $null
    $Global:UclStoreVer = [int]$Global:UclStoreVer + 1
}

# Put the tools into the page that is open right now (safe to repeat: tools never load twice)
function Invoke-InjectNow {
    param($S, [int]$ContextId = 0)
    if (-not (Test-WebUrl $S.Url)) { return }
    $ctx = if ($ContextId -gt 0) { ',"contextId":' + $ContextId } else { '' }
    [void](Send-Cdp -SessionId $S.SessionId -Method 'Runtime.evaluate' -ParamsJson ('{"expression":' + (Get-StoreJson) + $ctx + '}'))
    [void](Send-Cdp -SessionId $S.SessionId -Method 'Runtime.evaluate' -ParamsJson ('{"expression":' + (Get-BundleJson) + $ctx + '}'))
    $S.InjectedOrigin = Get-UrlOrigin $S.Url
}

function Register-Bundle {
    param($S)
    if ($S.BundleScriptId) {
        [void](Send-Cdp -SessionId $S.SessionId -Method 'Page.removeScriptToEvaluateOnNewDocument' -ParamsJson ('{"identifier":' + (JStr $S.BundleScriptId) + '}'))
        $S.BundleScriptId = $null
    }
    $S.PendingBundleReq = Send-Cdp -SessionId $S.SessionId -Method 'Page.addScriptToEvaluateOnNewDocument' -ParamsJson ('{"source":' + (Get-BundleJson) + '}') -Purpose 'bundle' -Session $S
}

function Register-Store {
    param($S)
    if ($S.StoreScriptId) {
        [void](Send-Cdp -SessionId $S.SessionId -Method 'Page.removeScriptToEvaluateOnNewDocument' -ParamsJson ('{"identifier":' + (JStr $S.StoreScriptId) + '}'))
        $S.StoreScriptId = $null
    }
    $S.PendingStoreReq = Send-Cdp -SessionId $S.SessionId -Method 'Page.addScriptToEvaluateOnNewDocument' -ParamsJson ('{"source":' + (Get-StoreJson) + '}') -Purpose 'store' -Session $S
    $S.StoreVer = [int]$Global:UclStoreVer
}

function Add-PageSession {
    param([string]$SessionId, $Info, [bool]$Waiting = $false)
    $tid = [string]$Info.targetId
    $Global:UclAttaching.Remove($tid)
    $isPage = [string]$Info.type -eq 'page' -and [string]$Info.url -notmatch '^(devtools|chrome-extension|chrome-untrusted)://'
    if (-not $isPage -or $Global:UclSessions.ContainsKey($tid)) {
        # Not a normal tab (or already handled): let it continue and leave it alone
        if ($Waiting) { [void](Send-Cdp -SessionId $SessionId -Method 'Runtime.runIfWaitingForDebugger') }
        [void](Send-Cdp -Method 'Target.detachFromTarget' -ParamsJson ('{"sessionId":' + (JStr $SessionId) + '}'))
        return
    }
    $s = [pscustomobject]@{
        TargetId = $tid; SessionId = $SessionId; Name = $tid; Url = [string]$Info.url; InjectedOrigin = ''
        StoreScriptId = $null; PendingStoreReq = 0; BundleScriptId = $null; PendingBundleReq = 0; StartedPaused = $Waiting
        ResumePending = $false; ResumeBy = (Get-Date); StoreVer = -1; Visible = $true
    }
    $Global:UclSessions[$tid] = $s
    $Global:UclSessionIds[$SessionId] = $tid
    # Page events (needed so "run on every load" works), the panel/tool channel,
    # the saved data and the tools for every page this tab loads ...
    [void](Send-Cdp -SessionId $SessionId -Method 'Page.enable')
    [void](Send-Cdp -SessionId $SessionId -Method 'Runtime.enable')
    [void](Send-Cdp -SessionId $SessionId -Method 'Runtime.addBinding' -ParamsJson '{"name":"__uclSend"}')
    Register-Store $s
    Register-Bundle $s
    $now = Get-Date
    foreach ($ms in 400, 1500, 4000) { [void]$Global:UclRechecks.Add([pscustomobject]@{ Session = $s; At = $now.AddMilliseconds($ms) }) }
    if ($Waiting) {
        # ... a brand-new tab: everything is registered, let it start loading now
        [void](Send-Cdp -SessionId $SessionId -Method 'Runtime.runIfWaitingForDebugger')
    } else {
        # ... a tab that was already open: also run the tools on its current page
        Invoke-InjectNow $s
    }
}

function Send-ToolCheck {
    param($S, [int]$ContextId = 0)
    $ctx = if ($ContextId -gt 0) { ',"contextId":' + $ContextId } else { '' }
    $id = Send-Cdp -SessionId $S.SessionId -Method 'Runtime.evaluate' -ParamsJson ('{"expression":"JSON.stringify([window.__UCL_DOC__ === document && typeof window.__UCL_TOOLS__ === \"object\", location.href])","returnByValue":true' + $ctx + '}') -Purpose 'check' -Session $S
    if ($id -and $ContextId -gt 0) { $Global:UclBrowser.Expect[[string]$id].TargetId = [string]$ContextId }
}

function Resume-IfReady {
    param($S, [switch]$Force)
    if (-not $S.ResumePending) { return }
    if ($Force -or ($S.StoreScriptId -and $S.BundleScriptId)) {
        $S.ResumePending = $false
        [void](Send-Cdp -SessionId $S.SessionId -Method 'Runtime.runIfWaitingForDebugger')
    }
}

function Remove-PageSession {
    param([string]$TargetId)
    $s = $Global:UclSessions[$TargetId]
    if ($s) { $Global:UclSessionIds.Remove($s.SessionId); $Global:UclSessions.Remove($TargetId) }
    $Global:UclAttaching.Remove($TargetId)
}

# Our own command's reply: keep track of the scripts registered in each tab
function Invoke-ReplyMessage {
    param([string]$Text)
    $m = [regex]::Match($Text, '^\{"id":(\d+)')
    $b = $Global:UclBrowser
    if (-not $m.Success -or -not $b) { return }
    $key = $m.Groups[1].Value
    if (-not $b.Expect.ContainsKey($key)) { return }
    $info = $b.Expect[$key]
    $b.Expect.Remove($key)
    try { $o = $Text | ConvertFrom-Json } catch { return }
    if ($info.Purpose -eq 'attach') {
        if ($o.error) { $Global:UclAttaching.Remove($info.TargetId) }
        return
    }
    if ($info.Purpose -eq 'check') {
        # A page finished building: if the tools are not on it, add them now
        $cs = $info.Session
        if (-not $cs -or -not $Global:UclSessions.ContainsKey($cs.TargetId)) { return }
        try { $v = [string]$o.result.result.value | ConvertFrom-Json } catch { return }
        if ($v -and $v.Count -ge 2) {
            $cs.Url = [string]$v[1]
            if (-not $v[0] -and (Test-WebUrl $cs.Url)) {
                $Global:UclLateInjects++
                $cid = 0
                if ($info.TargetId) { [void][int]::TryParse([string]$info.TargetId, [ref]$cid) }
                Invoke-InjectNow $cs $cid
            }
        }
        return
    }
    $s = $info.Session
    $ident = if ($o.result) { [string]$o.result.identifier } else { '' }
    if (-not $s) { return }
    if (-not $ident) { Resume-IfReady $s -Force; return }
    $live = $Global:UclSessions.ContainsKey($s.TargetId) -and [object]::ReferenceEquals($Global:UclSessions[$s.TargetId], $s)
    if ($info.Purpose -eq 'store') {
        if ($live -and [int]$key -eq $s.PendingStoreReq) { $s.StoreScriptId = $ident; Resume-IfReady $s }
        elseif ($live) { [void](Send-Cdp -SessionId $s.SessionId -Method 'Page.removeScriptToEvaluateOnNewDocument' -ParamsJson ('{"identifier":' + (JStr $ident) + '}')) }
    } elseif ($info.Purpose -eq 'bundle') {
        if ($live -and [int]$key -eq $s.PendingBundleReq) { $s.BundleScriptId = $ident; Resume-IfReady $s }
        elseif ($live) { [void](Send-Cdp -SessionId $s.SessionId -Method 'Page.removeScriptToEvaluateOnNewDocument' -ParamsJson ('{"identifier":' + (JStr $ident) + '}')) }
    }
}

function Invoke-BrowserMessage {
    param([string]$Text, $Requests)
    if ($Text.StartsWith('{"id":')) { Invoke-ReplyMessage $Text; return }
    $mm = [regex]::Match($Text, '^\{"method":"([^"]+)"')
    if (-not $mm.Success) { return }
    switch ($mm.Groups[1].Value) {
        'Runtime.bindingCalled' {
            try { $o = $Text | ConvertFrom-Json } catch { return }
            if ($o.params.name -ne '__uclSend') { return }
            $tid = $Global:UclSessionIds[[string]$o.sessionId]
            $s = if ($tid) { $Global:UclSessions[$tid] } else { $null }
            if ($s) { [void]$Requests.Add([pscustomobject]@{ Sid = $tid; Url = $s.Url; Payload = [string]$o.params.payload }) }
        }
        'Page.frameStartedLoading' {
            # A tab is about to load a page: make sure its saved-data copy is current
            $sm = [regex]::Match($Text, '"frameId":"([^"]+)".*"sessionId":"([^"]+)"')
            if (-not $sm.Success) { return }
            $tid = $Global:UclSessionIds[$sm.Groups[2].Value]
            $s = if ($tid) { $Global:UclSessions[$tid] } else { $null }
            if ($s -and $sm.Groups[1].Value -eq $s.TargetId -and $s.StoreVer -ne [int]$Global:UclStoreVer) { Register-Store $s }
        }
        'Runtime.executionContextCreated' {
            if ($Text -notmatch '"isDefault":true') { return }
            try { $o = $Text | ConvertFrom-Json } catch { return }
            $tid = $Global:UclSessionIds[[string]$o.sessionId]
            $s = if ($tid) { $Global:UclSessions[$tid] } else { $null }
            $c = $o.params.context
            # main frame of the tab only (its frame id is the tab id)
            if ($s -and [string]$c.auxData.frameId -eq $s.TargetId) {
                if ($c.origin) { $s.Url = [string]$c.origin + '/' }
                Send-ToolCheck $s ([int]$c.id)
            }
        }
        { $_ -eq 'Page.domContentEventFired' -or $_ -eq 'Page.loadEventFired' } {
            $sm = [regex]::Match($Text, '"sessionId":"([^"]+)"')
            if (-not $sm.Success) { return }
            $tid = $Global:UclSessionIds[$sm.Groups[1].Value]
            $s = if ($tid) { $Global:UclSessions[$tid] } else { $null }
            if ($s) { Send-ToolCheck $s }
        }
        'Target.targetCreated' {
            try { $o = $Text | ConvertFrom-Json } catch { return }
            # Brand-new tabs arrive through auto-attach (already paused); this catches tabs that
            # were open before the launcher started
            if (-not $Global:UclBrowser.AutoAttachSeen -or ((Get-Date) - $Global:UclBrowser.ConnectedAt).TotalSeconds -lt 3) {
                $tid = [string]$o.params.targetInfo.targetId
                $Global:UclPendingExisting[$tid] = $o.params.targetInfo
            }
        }
        'Target.targetInfoChanged' {
            try { $o = $Text | ConvertFrom-Json } catch { return }
            $info = $o.params.targetInfo
            $s = $Global:UclSessions[[string]$info.targetId]
            if (-not $s) {
                # Chrome hands new tabs to us itself; only reach out for tabs it did not
                if (-not $Global:UclBrowser.AutoAttachSeen) { Request-Attach $info }
                return
            }
            $s.Url = [string]$info.url
        }
        'Target.attachedToTarget' {
            try { $o = $Text | ConvertFrom-Json } catch { return }
            $Global:UclBrowser.AutoAttachSeen = $true
            $Global:UclPendingExisting.Remove([string]$o.params.targetInfo.targetId)
            Add-PageSession -SessionId ([string]$o.params.sessionId) -Info $o.params.targetInfo -Waiting ([bool]$o.params.waitingForDebugger)
        }
        'Target.detachedFromTarget' {
            try { $o = $Text | ConvertFrom-Json } catch { return }
            $tid = $Global:UclSessionIds[[string]$o.params.sessionId]
            if ($tid) { Remove-PageSession $tid }
        }
        'Target.targetDestroyed' {
            try { $o = $Text | ConvertFrom-Json } catch { return }
            Remove-PageSession ([string]$o.params.targetId)
        }
    }
}

# Read everything Chrome sent since the last tick
function Invoke-BrowserPump {
    $requests = New-Object System.Collections.ArrayList
    $b = $Global:UclBrowser
    if (-not $b) { return $requests }
    $guard = 0
    while ($Global:UclBrowser -and $b.Pending.IsCompleted -and $guard -lt 5000) {
        $guard++
        if ($b.Pending.IsFaulted -or $b.Pending.IsCanceled) { Disconnect-Browser; break }
        $r = $b.Pending.Result
        if ($r.MessageType -eq [System.Net.WebSockets.WebSocketMessageType]::Close) { Disconnect-Browser; break }
        [void]$b.Sb.Append([System.Text.Encoding]::UTF8.GetString($b.Buf, 0, $r.Count))
        if ($r.EndOfMessage) {
            $txt = $b.Sb.ToString()
            [void]$b.Sb.Clear()
            try { Invoke-BrowserMessage -Text $txt -Requests $requests } catch { $Global:UclLastError = 'Message handling: ' + $_.Exception.Message }
        }
        if ($Global:UclBrowser) { Start-BrowserReceive }
    }
    if ($Global:UclBrowser -and $Global:UclPendingExisting -and $Global:UclPendingExisting.Count -and ((Get-Date) - $Global:UclBrowser.ConnectedAt).TotalMilliseconds -gt 1000) {
        foreach ($tid in @($Global:UclPendingExisting.Keys)) {
            $info = $Global:UclPendingExisting[$tid]
            $Global:UclPendingExisting.Remove($tid)
            if (-not $Global:UclSessions.ContainsKey($tid)) { Request-Attach $info }
        }
    }
    # A paused new tab must never wait long
    foreach ($tid in @($Global:UclSessions.Keys)) {
        $ps = $Global:UclSessions[$tid]
        if ($ps -and $ps.ResumePending -and (Get-Date) -ge $ps.ResumeBy) { Resume-IfReady $ps -Force }
    }
    # Scheduled checks on new tabs
    if ($Global:UclRechecks -and $Global:UclRechecks.Count) {
        $now = Get-Date
        foreach ($rc in $Global:UclRechecks.ToArray()) {
            if ($rc.At -gt $now) { continue }
            [void]$Global:UclRechecks.Remove($rc)
            if ($Global:UclSessions.ContainsKey($rc.Session.TargetId) -and [object]::ReferenceEquals($Global:UclSessions[$rc.Session.TargetId], $rc.Session)) { Send-ToolCheck $rc.Session }
        }
    }
    # Forget attach requests Chrome never answered (the tab will be retried on its next change)
    foreach ($tid in @($Global:UclAttaching.Keys)) {
        if (((Get-Date) - $Global:UclAttaching[$tid]).TotalSeconds -gt 10) { $Global:UclAttaching.Remove($tid) }
    }
    return $requests
}

# New pages must start with the latest saved values: refresh the registered copy in every tab
function Update-StoreScripts {
    $Global:UclStoreJson = $null
    foreach ($tid in @($Global:UclSessions.Keys)) {
        $s = $Global:UclSessions[$tid]
        if ($s) { Register-Store $s }
    }
}

# Tool list or on/off switches changed: register the new tools in every tab and run them now
function Restart-AutoLoad {
    if (-not $Global:UclBrowser) { Update-TrayStatus; return }
    $Global:UclBundleText = New-ToolBundle
    $Global:UclBundleJson = $null
    foreach ($tid in @($Global:UclSessions.Keys)) {
        $s = $Global:UclSessions[$tid]
        if (-not $s) { continue }
        Register-Bundle $s
        if (Test-WebUrl $s.Url) {
            [void](Send-Cdp -SessionId $s.SessionId -Method 'Runtime.evaluate' -ParamsJson ('{"expression":' + (Get-BundleJson) + '}'))
        }
    }
    Update-TrayStatus
}

function Invoke-PanelRequests {
    param($Requests)
    $list = New-Object System.Collections.Generic.List[string]
    foreach ($c in @($Global:UclSettings.checked)) { $list.Add([string]$c) }
    $valid = $false
    foreach ($item in $Requests) {
        if ($item -is [string]) { $raw = $item; $url = 'https://atlas.almosafer.com/'; $sid = $null }
        else { $raw = [string]$item.Payload; $url = [string]$item.Url; $sid = $item.Sid }
        try { $r = $raw | ConvertFrom-Json } catch { continue }
        if (@('gm_set', 'gm_del', 'gm_need', 'gm_catchup', 'xhr', 'vis') -contains [string]$r.action) {
            if ($Global:UclSettings.token -and [string]$r.token -eq [string]$Global:UclSettings.token) {
                if ($Global:UclPerf -and $r.at) {
                    try {
                        $d = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds() - [long]$r.at
                        $Global:UclPerf.RelayMs = $d
                        if ($d -gt $Global:UclPerf.RelayMaxMs) { $Global:UclPerf.RelayMaxMs = $d }
                    } catch {}
                }
                try { Invoke-ToolRequest -R $r -Sid $sid } catch { $Global:UclLastError = 'Tool request failed: ' + $_.Exception.Message }
            }
            continue
        }
        if ($url -notmatch '^https://atlas\.almosafer\.com/') { continue }
        if ($r.action -eq 'hello') {
            $em = ([string]$r.email).Trim().ToLowerInvariant()
            if ($em -match '^[^@\s]+@almosafer\.com$' -and $em -ne [string]$Global:UclSettings.email) {
                $Global:UclSettings.email = $em
                Save-Settings
                $Global:UclSyncRequested = $true
            }
            continue
        }
        if ($r.action -eq 'sync') { $Global:UclSyncRequested = $true; continue }
        if ($r.action -ne 'toggle') { continue }
        $key = [string]$r.key
        if (-not $key -or $key -match '[\\/]' -or $key -notlike '*.js') { continue }
        if (-not (Test-ToolExists $key)) { continue }
        $valid = $true
        if ($r.on -and -not $list.Contains($key)) { $list.Add($key) }
        if (-not $r.on -and $list.Contains($key)) { [void]$list.Remove($key) }
    }
    if (-not $valid) { return }
    $Global:UclSettings.checked = @($list)
    Save-Settings
    Update-ToolList
    Restart-AutoLoad
}

# ---------------------------------------------------------------------
#  SUPABASE SYNC (same function as the old Tampermonkey launcher)
# ---------------------------------------------------------------------
function Get-SafeToolFileName {
    param([string]$Key)
    $n = ($Key -replace '[\\/:*?"<>|]', '_').Trim().TrimStart('.')
    if (-not $n) { $n = 'tool' }
    if ($n -notlike '*.js') { $n += '.js' }
    return $n
}

function Set-SyncStatus {
    param([string]$Status, [string]$Message = '')
    $Global:UclSync.status = $Status
    $Global:UclSync.message = $Message
}


function Test-SyncDue {
    if ($Global:UclSyncTask) { return $false }
    if (-not $Global:UclSettings.email) { return $false }
    if ($Global:UclSyncRequested) { return $true }
    if ($Global:UclNextSyncTry -and (Get-Date) -lt $Global:UclNextSyncTry) { return $false }
    if (-not $Global:UclSyncedThisRun) { return $true }
    $last = $null
    try { if ($Global:UclSettings.lastSync) { $last = [datetime]::Parse([string]$Global:UclSettings.lastSync) } } catch {}
    if (-not $last) { return $true }
    return ((Get-Date) - $last).TotalHours -ge $SyncHours
}

# Ask Supabase in the background (the launcher keeps serving tabs meanwhile)
function Start-CloudSync {
    $Global:UclSyncRequested = $false
    $Global:UclSyncedThisRun = $true
    $Global:UclSync.n++
    $email = [string]$Global:UclSettings.email
    if (-not $email) { Set-SyncStatus 'no-email'; return }
    try {
        $msg = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::Post, ($SupabaseUrl + '/functions/v1/get-my-tools'))
        [void]$msg.Headers.TryAddWithoutValidation('apikey', $SupabaseAnonKey)
        [void]$msg.Headers.TryAddWithoutValidation('Authorization', ('Bearer ' + $SupabaseAnonKey))
        $msg.Content = New-Object System.Net.Http.StringContent(('{"email":' + (JStr $email) + '}'), [System.Text.Encoding]::UTF8, 'application/json')
        $Global:UclSyncCts = New-Object System.Threading.CancellationTokenSource(25000)
        $Global:UclSyncTask = $Global:UclHttp.SendAsync($msg, $Global:UclSyncCts.Token)
    } catch {
        Complete-CloudSync -ErrorMessage $_.Exception.GetBaseException().Message
    }
}

function Update-CloudSyncTask {
    $t = $Global:UclSyncTask
    if (-not $t -or -not $t.IsCompleted) { return }
    $Global:UclSyncTask = $null
    try { $Global:UclSyncCts.Dispose() } catch {}
    if ($t.IsCanceled) { Complete-CloudSync -ErrorMessage 'The server took too long to answer'; return }
    if ($t.IsFaulted) { Complete-CloudSync -ErrorMessage $t.Exception.GetBaseException().Message; return }
    $resp = $t.Result
    try {
        $bytes = $resp.Content.ReadAsByteArrayAsync().Result
        $text = [System.Text.Encoding]::UTF8.GetString($bytes)
        if (-not $resp.IsSuccessStatusCode) { Complete-CloudSync -ErrorMessage ('Server error (' + [int]$resp.StatusCode + ')'); return }
        Complete-CloudSync -Text $text
    } catch { Complete-CloudSync -ErrorMessage $_.Exception.GetBaseException().Message }
    finally { try { $resp.Dispose() } catch {} }
}

function Complete-CloudSync {
    param([string]$Text = '', [string]$ErrorMessage = '')
    $data = $null
    if (-not $ErrorMessage) { try { $data = $Text | ConvertFrom-Json } catch { $ErrorMessage = 'Server answer could not be read' } }
    if ($ErrorMessage) {
        # Server unreachable: keep using the saved tools, retry in 5 minutes
        $Global:UclNextSyncTry = (Get-Date).AddMinutes(5)
        Set-SyncStatus 'offline' $ErrorMessage
        Restart-AutoLoad
        return
    }
    $Global:UclNextSyncTry = $null
    $backend = [string]$data.status
    $tools = @($data.tools | Where-Object { $_ -and $_.tool_key -and $_.code })
    if (-not $backend) { $backend = if ($tools.Count) { 'ok' } else { 'no_tools' } }
    if ($backend -eq 'inactive' -or $backend -eq 'not_found') { $tools = @() }

    if (-not (Test-Path -LiteralPath $ToolsDir)) { New-Item -ItemType Directory -Path $ToolsDir | Out-Null }
    $enc = New-Object System.Text.UTF8Encoding($false)
    $oldCloud = @($Global:UclSettings.cloud)
    $newCloud = @()
    $Global:UclCloudDesc = @{}
    foreach ($t in $tools) {
        $file = Get-SafeToolFileName ([string]$t.tool_key)
        if ($newCloud -contains $file) { continue }
        Save-CloudTool -File $file -Code ([string]$t.code)
        $newCloud += $file
        if ($t.description) { $Global:UclCloudDesc[$file] = [string]$t.description }
        if (@($Global:UclSettings.known) -notcontains $file) {
            # First time this tool is assigned: switch it on (like the old launcher)
            $Global:UclSettings.known = @($Global:UclSettings.known) + $file
            if (@($Global:UclSettings.checked) -notcontains $file) { $Global:UclSettings.checked = @($Global:UclSettings.checked) + $file }
        }
    }
    # Tools no longer assigned to this account: remove the saved copy
    foreach ($old in $oldCloud) {
        if ($newCloud -notcontains $old) {
            Remove-CloudTool $old
            $Global:UclSettings.checked = @($Global:UclSettings.checked | Where-Object { $_ -ne $old })
            $Global:UclSettings.known   = @($Global:UclSettings.known   | Where-Object { $_ -ne $old })
        }
    }
    $Global:UclSettings.cloud = $newCloud
    $Global:UclSettings.lastSync = (Get-Date).ToString('yyyy-MM-ddTHH:mm:ssK')
    Save-Settings
    Set-SyncStatus $backend
    Update-ToolList
    Restart-AutoLoad
}

function Invoke-EngineTick {
    $Global:UclTickCount++
    if (-not $Global:UclBrowser) {
        # Not connected: try again about every 2 seconds
        if ($Global:UclTickCount % 20 -eq 1) { [void](Connect-Browser); Update-TrayStatus }
    } else {
        $req = @(Invoke-BrowserPump)
        if ($req.Count -gt 0) { Invoke-PanelRequests -Requests $req }
        Update-XhrJobs
        $Global:UclGmDirty = $false
    }
    Update-CloudSyncTask
    if (Test-SyncDue) { Start-CloudSync }
    if ($Global:UclTickCount % 10 -eq 0) { Update-TrayStatus }
    try { Update-LauncherUpdate } catch { $Global:UclUpd.Status = 'Update check failed: ' + $_.Exception.Message; $Global:UclUpd.Task = $null; $Global:UclUpd.NextAt = (Get-Date).AddMinutes(30) }
    # The installer asks a running copy to close (so it can be updated cleanly)
    if ($Global:UclQuitEvent -and $Global:UclQuitEvent.WaitOne(0)) { Stop-Launcher }
}

# ---------------------------------------------------------------------
#  SELF-UPDATE (v0.18)
#  Reads atlas-tools-latest.json from the public Supabase Storage bucket
#  "launcher-releases" (the Tampermonkey launcher's files there are not used).
#  A new launcher is only accepted when ALL checks pass:
#    newer version, exact size, SHA-256, RSA signature (made with the
#    publisher's private key), plain text, expected header, no syntax errors.
#  It is saved as AtlasTools.ps1 (the old file is kept as
#  AtlasTools.previous.ps1) and used after "Restart to update" or next start.
#  If anything fails, the current file is not touched.
# ---------------------------------------------------------------------
$Global:UclUpd = [pscustomobject]@{ Task = $null; Cts = $null; Stage = ''; Info = $null; NextAt = (Get-Date).AddSeconds(45); Requested = $false; Manual = $false; Status = 'Not checked yet'; Ready = '' }

function ConvertTo-LauncherVersion {
    param([string]$Text)
    $v = $null
    if ($Text -match '^\d+(\.\d+){1,3}$' -and [version]::TryParse($Text, [ref]$v)) { return $v }
    return $null
}

function Get-TextLauncherVersion {
    param([string]$Text)
    $m = [regex]::Match($Text, "(?m)^\`$LauncherVersion\s*=\s*'(\d+(?:\.\d+){1,3})'")
    if ($m.Success) { return $m.Groups[1].Value } else { return '' }
}

function Get-DiskLauncherVersion {
    try {
        if (Test-Path -LiteralPath $LauncherFile) { return (Get-TextLauncherVersion ([System.IO.File]::ReadAllText($LauncherFile))) }
    } catch {}
    return ''
}

# Returns '' when the downloaded file is acceptable, otherwise the reason
function Test-UpdateFile {
    param([byte[]]$Bytes, $Info)
    if ($Bytes.Length -ne [long]$Info.size) { return 'size does not match' }
    if ($Bytes.Length -gt $UpdateMaxBytes) { return 'file is too big' }
    $sha = [System.Security.Cryptography.SHA256]::Create()
    $hex = -join ($sha.ComputeHash($Bytes) | ForEach-Object { $_.ToString('x2') })
    $sha.Dispose()
    if ($hex -ne ([string]$Info.sha256).ToLowerInvariant()) { return 'SHA-256 does not match' }
    $ok = $false
    try {
        $rsa = New-Object System.Security.Cryptography.RSACryptoServiceProvider
        $rsa.PersistKeyInCsp = $false
        $rsa.FromXmlString($UpdatePublicKey)
        $ok = $rsa.VerifyData($Bytes, 'SHA256', [Convert]::FromBase64String([string]$Info.signature))
        $rsa.Dispose()
    } catch { $ok = $false }
    if (-not $ok) { return 'signature is not valid' }
    foreach ($by in $Bytes) { if ($by -gt 127) { return 'file is not plain text' } }
    $text = [System.Text.Encoding]::ASCII.GetString($Bytes)
    if (-not $text.StartsWith('# =====') -or $text.IndexOf('Atlas Tools Launcher') -lt 0) { return 'unexpected file header' }
    if ($text.IndexOf("'Local\AtlasToolsLauncher'") -lt 0) { return 'single-copy check missing' }
    if ((Get-TextLauncherVersion $text) -ne [string]$Info.version) { return 'version inside the file does not match' }
    $errs = $null
    [void][System.Management.Automation.Language.Parser]::ParseInput($text, [ref]$null, [ref]$errs)
    if ($errs -and $errs.Count) { return 'file has syntax errors' }
    return ''
}

function Install-UpdateFile {
    param([byte[]]$Bytes)
    $new  = $LauncherFile + '.new'
    $prev = Join-Path $BaseDir 'AtlasTools.previous.ps1'
    [System.IO.File]::WriteAllBytes($new, $Bytes)
    if (Test-Path -LiteralPath $LauncherFile) {
        [System.IO.File]::Replace($new, $LauncherFile, $prev)
    } else {
        [System.IO.File]::Move($new, $LauncherFile)
    }
}

function Test-UpdateDue {
    if ($Global:UclUpd.Task) { return $false }
    if (-not $UpdatePublicKey) { $Global:UclUpd.Status = 'Self-update is not set up in this copy'; return $false }
    if ($Global:UclUpd.Requested) { return $true }
    if ($Global:UclUpd.Ready) { return $false }
    return ((Get-Date) -ge $Global:UclUpd.NextAt)
}

function Start-UpdateRequest {
    param([string]$Url, [string]$Stage)
    $msg = New-Object System.Net.Http.HttpRequestMessage([System.Net.Http.HttpMethod]::Get, $Url)
    [void]$msg.Headers.TryAddWithoutValidation('Cache-Control', 'no-cache')
    $Global:UclUpd.Cts = New-Object System.Threading.CancellationTokenSource(60000)
    $Global:UclUpd.Stage = $Stage
    $Global:UclUpd.Task = $Global:UclHttp.SendAsync($msg, $Global:UclUpd.Cts.Token)
}

function Complete-UpdateCheck {
    param([string]$Status, [double]$RetryHours = $UpdateHours)
    $Global:UclUpd.Status = $Status + ' (' + (Get-Date).ToString('HH:mm') + ')'
    $Global:UclUpd.NextAt = (Get-Date).AddHours($RetryHours)
    if ($Global:UclUpd.Manual -and -not $Global:UclUpd.Ready -and $tray) {
        $tray.ShowBalloonTip(4000, 'Atlas Tools', $Status, [System.Windows.Forms.ToolTipIcon]::Info)
    }
    $Global:UclUpd.Manual = $false
}

function Show-UpdateReady {
    param([string]$Version)
    $Global:UclUpd.Ready = $Version
    $Global:UclUpd.Status = 'Version ' + $Version + ' is ready - restart to use it'
    if ($miRestart) { $miRestart.Text = 'Restart to update to v' + $Version; $miRestart.Visible = $true }
    if ($tray) {
        $tray.ShowBalloonTip(10000, 'Atlas Tools update ready', 'Version ' + $Version + ' is downloaded. Click here to restart Atlas Tools now (your Chrome tabs stay open).', [System.Windows.Forms.ToolTipIcon]::Info)
    }
}

function Update-LauncherUpdate {
    $u = $Global:UclUpd
    if (-not $u.Task) {
        if (Test-UpdateDue) {
            $u.Requested = $false
            $u.Status = 'Checking for updates...'
            Start-UpdateRequest -Url ($UpdateBaseUrl + $UpdateJsonName + '?t=' + [DateTime]::UtcNow.Ticks) -Stage 'json'
        }
        return
    }
    $t = $u.Task
    if (-not $t.IsCompleted) { return }
    $u.Task = $null
    try { $u.Cts.Dispose() } catch {}
    if ($t.IsCanceled -or $t.IsFaulted) { Complete-UpdateCheck 'Update server not reachable' 0.5; return }
    $resp = $t.Result
    try {
        if (-not $resp.IsSuccessStatusCode) {
            if ([int]$resp.StatusCode -eq 400 -or [int]$resp.StatusCode -eq 404) { Complete-UpdateCheck 'No update published yet' }
            else { Complete-UpdateCheck ('Update server error (' + [int]$resp.StatusCode + ')') 0.5 }
            return
        }
        $bytes = $resp.Content.ReadAsByteArrayAsync().Result
    } finally { try { $resp.Dispose() } catch {} }

    if ($u.Stage -eq 'json') {
        $info = $null
        try { $info = [System.Text.Encoding]::UTF8.GetString($bytes) | ConvertFrom-Json } catch {}
        if (-not $info -or -not (ConvertTo-LauncherVersion ([string]$info.version)) -or
            [string]$info.file -notmatch '^AtlasTools-\d+(\.\d+){1,3}\.ps1$' -or
            [string]$info.sha256 -notmatch '^[0-9a-fA-F]{64}$' -or -not $info.signature -or [long]$info.size -le 0) {
            Complete-UpdateCheck 'Update information could not be read'
            return
        }
        $newV  = ConvertTo-LauncherVersion ([string]$info.version)
        $runV  = ConvertTo-LauncherVersion $LauncherVersion
        $diskS = Get-DiskLauncherVersion
        $diskV = ConvertTo-LauncherVersion $diskS
        if ($newV -le $runV) { Complete-UpdateCheck ('You have the latest version (v' + $LauncherVersion + ')'); return }
        if ($diskV -and $diskV -ge $newV) { Complete-UpdateCheck 'Update already downloaded'; Show-UpdateReady $diskS; return }
        if ([long]$info.size -gt $UpdateMaxBytes) { Complete-UpdateCheck 'Update refused: file is too big'; return }
        $u.Info = $info
        $u.Status = 'Downloading version ' + [string]$info.version + '...'
        Start-UpdateRequest -Url ($UpdateBaseUrl + [string]$info.file + '?t=' + [DateTime]::UtcNow.Ticks) -Stage 'file'
        return
    }

    # Stage 'file': check everything before touching AtlasTools.ps1
    $info = $u.Info
    $why = Test-UpdateFile -Bytes $bytes -Info $info
    if ($why) { Complete-UpdateCheck ('Update v' + [string]$info.version + ' refused: ' + $why); return }
    try { Install-UpdateFile -Bytes $bytes } catch { Complete-UpdateCheck ('Update could not be saved: ' + $_.Exception.Message) 0.5; return }
    Complete-UpdateCheck ('Downloaded version ' + [string]$info.version)
    Show-UpdateReady ([string]$info.version)
}

# Start the (updated) launcher again; the new copy waits until this one has closed
function Restart-Launcher {
    $v = Get-DiskLauncherVersion
    if (-not $v) {
        [void][System.Windows.Forms.MessageBox]::Show('The launcher file is missing, so Atlas Tools cannot restart. Run "Install Atlas Tools" again.', 'Atlas Tools')
        return
    }
    $ps = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
    $cmd = '-NoProfile -WindowStyle Hidden -Command "iex (Get-Content -Raw (Join-Path $env:USERPROFILE ''Universal-Chrome-Launcher\AtlasTools.ps1''))"'
    $env:ATLAS_TOOLS_RESTART = '1'
    try { Start-Process -FilePath $ps -ArgumentList $cmd -WindowStyle Hidden } catch {
        $env:ATLAS_TOOLS_RESTART = $null
        [void][System.Windows.Forms.MessageBox]::Show('Atlas Tools could not restart: ' + $_.Exception.Message + [Environment]::NewLine + 'Quit it from the tray and start it from the desktop.', 'Atlas Tools')
        return
    }
    $env:ATLAS_TOOLS_RESTART = $null
    Stop-Launcher
}

# ---------------------------------------------------------------------
#  WORK Chrome starter + tray status
# ---------------------------------------------------------------------
$ChromeExe = @(
    (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe'),
    (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe'),
    (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe')
) | Where-Object { $_ -and (Test-Path -LiteralPath $_) } | Select-Object -First 1
$WorkProfileDir = Join-Path $env:USERPROFILE 'AtlasLauncherProfile'

function Start-WorkChrome {
    if (-not $ChromeExe) {
        if ($tray) { $tray.ShowBalloonTip(5000, 'Atlas Tools', 'Google Chrome was not found on this PC.', 'Warning') }
        return
    }
    Start-Process -FilePath $ChromeExe -ArgumentList @('--remote-debugging-port=9223', ('--user-data-dir="' + $WorkProfileDir + '"'), 'https://atlas.almosafer.com/')
}

function Update-TrayStatus {
    $n  = $Global:UclSessions.Count
    $on = @($Global:UclSettings.checked).Count
    $syst = if ($Global:UclSync) { [string]$Global:UclSync.status } else { '' }
    if ($syst -eq 'inactive' -or $syst -eq 'not_found') { $text = 'Account not active for Atlas Tools'; $ok = $false }
    elseif (-not $Global:UclConnected) { $text = 'Waiting for WORK Chrome'; $ok = $false }
    elseif ($n -eq 0) { $text = 'Connected - no tabs yet'; $ok = $true }
    else { $text = 'Connected - ' + $on + ' tool(s) on, ' + $n + ' tab(s)'; $ok = $true }
    if ($tray) {
        $tray.Icon = if ($ok) { $IconOk } else { $IconWait }
        $tt = 'Atlas Tools v' + $LauncherVersion + ': ' + $text
        if ($tt.Length -gt 63) { $tt = $tt.Substring(0, 63) }
        $tray.Text = $tt
        $miStatus.Text = $text
        if ($miSync) {
            $lbl = 'Sync tools now'
            try { if ($Global:UclSettings.lastSync) { $lbl += ' (last: ' + ([datetime]::Parse([string]$Global:UclSettings.lastSync)).ToString('HH:mm') + ')' } } catch {}
            if ($syst -eq 'offline') { $lbl += ' - server not reachable' }
            $miSync.Text = $lbl
        }
    }
    $color = if ($ok) { [System.Drawing.Color]::DarkGreen } else { [System.Drawing.Color]::DarkOrange }
    Set-Light $color $text
    if ($lblAuto) {
        $dl = ''
        if ($Global:UclXhrStats) {
            $dl = '  |  Downloads: ' + $Global:UclXhrJobs.Count + ' running, ' + $Global:UclXhrStats.Done + ' ok, ' + $Global:UclXhrStats.Failed + ' failed, last ' + $Global:UclXhrStats.LastMs + ' ms'
            if ($Global:UclXhrStats.LastError) { $dl += ' (last error: ' + $Global:UclXhrStats.LastError + ')' }
        }
        $perf = ''
        if ($Global:UclPerf) {
            $perf = '  |  Timing: tab sync ' + $Global:UclPerf.RelayMs + ' ms (max ' + $Global:UclPerf.RelayMaxMs + '), busiest moment ' + $Global:UclPerf.BusyMaxMs + ' ms, tabs connected ' + $Global:UclSessions.Count
        }
        $upd = if ($Global:UclUpd) { '  |  Updates: ' + $Global:UclUpd.Status } else { '' }
        $lblAuto.Text = 'Engine: ' + $text + $perf + $dl + $upd + $(if ($Global:UclLastError) { '  |  Last problem: ' + $Global:UclLastError } else { '' })
    }
}

function Set-Light {
    param($Color, [string]$Text)
    if ($lblMatch) { $lblMatch.Text = $Text; $lblMatch.ForeColor = $Color }
}


# ---------------------------------------------------------------------
#  Window
# ---------------------------------------------------------------------
$form = New-Object System.Windows.Forms.Form
$form.Text = 'Atlas Tools v' + $LauncherVersion + ' - Settings and details'
$form.Size = New-Object System.Drawing.Size(560, 380)
$form.FormBorderStyle = 'FixedSingle'
$form.MaximizeBox = $false
$form.StartPosition = 'CenterScreen'
$form.Font = New-Object System.Drawing.Font('Segoe UI', 9)

$lblMatch = New-Object System.Windows.Forms.Label
$lblMatch.Location = New-Object System.Drawing.Point(14, 12)
$lblMatch.Size = New-Object System.Drawing.Size(520, 28)
$lblMatch.Font = New-Object System.Drawing.Font('Segoe UI', 13, [System.Drawing.FontStyle]::Bold)
$lblMatch.Text = 'Starting...'
$form.Controls.Add($lblMatch)

$lblHint = New-Object System.Windows.Forms.Label
$lblHint.Location = New-Object System.Drawing.Point(14, 44)
$lblHint.Size = New-Object System.Drawing.Size(520, 20)
$lblHint.ForeColor = [System.Drawing.Color]::DimGray
$lblHint.Text = 'Tip: you can also switch tools on and off from the green dot next to your email in Atlas.'
$form.Controls.Add($lblHint)

$lblTools = New-Object System.Windows.Forms.Label
$lblTools.Location = New-Object System.Drawing.Point(14, 74)
$lblTools.Size = New-Object System.Drawing.Size(520, 20)
$lblTools.Font = New-Object System.Drawing.Font('Segoe UI', 9, [System.Drawing.FontStyle]::Bold)
$lblTools.Text = 'Your tools:'
$form.Controls.Add($lblTools)

$lstTools = New-Object System.Windows.Forms.CheckedListBox
$lstTools.CheckOnClick = $true
$lstTools.Location = New-Object System.Drawing.Point(14, 96)
$lstTools.Size = New-Object System.Drawing.Size(520, 190)
$lstTools.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$form.Controls.Add($lstTools)

$btnDetails = New-Object System.Windows.Forms.Button
$btnDetails.Location = New-Object System.Drawing.Point(14, 298)
$btnDetails.Size = New-Object System.Drawing.Size(150, 30)
$btnDetails.Text = 'Show details'
$form.Controls.Add($btnDetails)

$btnReloadList = New-Object System.Windows.Forms.Button
$btnReloadList.Location = New-Object System.Drawing.Point(384, 298)
$btnReloadList.Size = New-Object System.Drawing.Size(150, 30)
$btnReloadList.Text = 'Reload tools'
$form.Controls.Add($btnReloadList)

# --- Advanced view (hidden until "Show details") ---
$lblAuto = New-Object System.Windows.Forms.Label
$lblAuto.Location = New-Object System.Drawing.Point(14, 340)
$lblAuto.Size = New-Object System.Drawing.Size(520, 58)
$lblAuto.ForeColor = [System.Drawing.Color]::DarkBlue
$lblAuto.Text = 'Auto-load: starting'
$form.Controls.Add($lblAuto)

$txtStatus = New-Object System.Windows.Forms.TextBox
$txtStatus.Location = New-Object System.Drawing.Point(14, 400)
$txtStatus.Size = New-Object System.Drawing.Size(520, 164)
$txtStatus.Multiline = $true
$txtStatus.ReadOnly = $true
$txtStatus.ScrollBars = 'Vertical'
$txtStatus.Font = New-Object System.Drawing.Font('Consolas', 9)
$form.Controls.Add($txtStatus)

$btnRefresh = New-Object System.Windows.Forms.Button
$btnRefresh.Location = New-Object System.Drawing.Point(14, 572)
$btnRefresh.Size = New-Object System.Drawing.Size(160, 30)
$btnRefresh.Text = 'Refresh status'
$form.Controls.Add($btnRefresh)

$btnTest = New-Object System.Windows.Forms.Button
$btnTest.Location = New-Object System.Drawing.Point(184, 572)
$btnTest.Size = New-Object System.Drawing.Size(160, 30)
$btnTest.Text = 'Test: document.title'
$form.Controls.Add($btnTest)

$btnLoadTool = New-Object System.Windows.Forms.Button
$btnLoadTool.Location = New-Object System.Drawing.Point(354, 572)
$btnLoadTool.Size = New-Object System.Drawing.Size(180, 30)
$btnLoadTool.Text = 'Load selected (one-off)'
$form.Controls.Add($btnLoadTool)

$lblResult = New-Object System.Windows.Forms.Label
$lblResult.Location = New-Object System.Drawing.Point(14, 608)
$lblResult.Size = New-Object System.Drawing.Size(520, 18)
$lblResult.Text = 'Result:'
$form.Controls.Add($lblResult)

$txtResult = New-Object System.Windows.Forms.TextBox
$txtResult.Location = New-Object System.Drawing.Point(14, 628)
$txtResult.Size = New-Object System.Drawing.Size(520, 110)
$txtResult.Multiline = $true
$txtResult.ReadOnly = $true
$txtResult.ScrollBars = 'Vertical'
$txtResult.Font = New-Object System.Drawing.Font('Consolas', 9)
$form.Controls.Add($txtResult)

$AdvancedControls = @($lblAuto, $txtStatus, $btnRefresh, $btnTest, $btnLoadTool, $lblResult, $txtResult)
foreach ($c in $AdvancedControls) { $c.Visible = $false }

$Global:UclDetails = $false
function Set-Details {
    param([bool]$Show)
    $Global:UclDetails = $Show
    foreach ($c in $AdvancedControls) { $c.Visible = $Show }
    if ($Show) {
        $form.Size = New-Object System.Drawing.Size(560, 790)
        $btnDetails.Text = 'Hide details'
    } else {
        $form.Size = New-Object System.Drawing.Size(560, 380)
        $btnDetails.Text = 'Show details'
    }
}

# ---------------------------------------------------------------------
#  Refresh status (all v0.2 information + v0.3 matching)
# ---------------------------------------------------------------------
function Update-Status {
    $txtResult.Text = ''
    $form.Refresh()
    try {
        $cdp = Get-CdpInfo -WithVersion
        $sel = Get-WorkSelection
        $m   = Find-MatchingTarget -Selection $sel -Cdp $cdp

        $L = New-Object System.Collections.Generic.List[string]
        $L.Add('=== BROWSER (CDP 127.0.0.1:9223) ===')
        if ($cdp.Connected) {
            $L.Add('Status      : CONNECTED')
            $L.Add('Chrome      : ' + $cdp.Browser)
            $L.Add('Pages found : ' + @($cdp.Pages).Count)
            foreach ($p in @($cdp.Pages)) {
                $L.Add('  - Title : ' + $p.title)
                $L.Add('    URL   : ' + $p.url)
            }
        } else {
            $L.Add('Status      : NOT CONNECTED')
            $L.Add('Error       : ' + $cdp.Error)
        }
        $L.Add('')
        $L.Add('=== WORK CHROME SELECTED TAB (UI Automation) ===')
        $L.Add('WORK windows : ' + $sel.WindowCount)
        $L.Add('Window       : ' + $sel.WindowTitle)
        $L.Add('Window state : ' + $sel.WindowState)
        $L.Add('Selected tab : ' + $sel.CleanTab + '   (Chrome reports ' + $sel.SelectedCount + ' selected)')
        if ($sel.Url) { $L.Add('Address bar  : ' + $sel.Url) } else { $L.Add('Address bar  : (not read - title only)') }
        if (-not $sel.Ok) { $L.Add('Problem      : ' + $sel.Reason) }
        $L.Add('')
        $L.Add('=== CDP MATCH ===')
        $L.Add('Result : ' + $m.Status)
        $L.Add('Detail : ' + $m.Detail)
        if ($m.Target) {
            $L.Add('Target : ' + $m.Target.id)
            $L.Add('URL    : ' + $m.Target.url)
        }
        $L.Insert(0, 'Single-tab match (used by the two buttons below): ' + $m.Status)
        $L.Insert(1, '')
        $txtStatus.Text = ($L -join "`r`n")
    } catch {
        $txtStatus.Text = 'Error during refresh: ' + $_.Exception.Message
    }
}

# ---------------------------------------------------------------------
#  Buttons
# ---------------------------------------------------------------------
$btnRefresh.Add_Click({ Update-Status })
$btnDetails.Add_Click({ Set-Details (-not $Global:UclDetails) })

$btnTest.Add_Click({
    $txtResult.Text = 'Re-checking tab identity before running JavaScript...'
    $form.Refresh()
    # Always re-identify right before running anything
    $cdp = Get-CdpInfo
    $sel = Get-WorkSelection
    $m   = Find-MatchingTarget -Selection $sel -Cdp $cdp
    if ($m.Status -ne 'MATCHED') {
        Update-Status
        $txtResult.Text = "BLOCKED - JavaScript was NOT run.`r`nReason: " + $m.Status + ' - ' + $m.Detail
        return
    }
    try {
        $resp = Invoke-CdpEvaluate -WsUrl $m.Target.webSocketDebuggerUrl -Expression 'document.title'
        if ($resp.error) {
            $txtResult.Text = 'CDP error: ' + $resp.error.message
        } elseif ($resp.result.exceptionDetails) {
            $txtResult.Text = 'Page reported an error: ' + $resp.result.exceptionDetails.text
        } else {
            $val  = [string]$resp.result.result.value
            $same = if ($val -eq [string]$m.Target.title) { 'YES' } else { 'NO' }
            $txtResult.Text = "SUCCESS`r`ndocument.title = " + $val +
                "`r`nTarget ID      = " + $m.Target.id +
                "`r`nURL            = " + $m.Target.url +
                "`r`nMatches tab    = " + $same
        }
    } catch {
        $txtResult.Text = 'JavaScript test failed: ' + $_.Exception.GetBaseException().Message
    }
})

function Update-ToolList {
    $Global:UclLoadingList = $true
    $lstTools.Items.Clear()
    try {
        foreach ($f in Get-ToolFiles) {
            $isTicked = @($Global:UclSettings.checked) -contains $f.Name
            [void]$lstTools.Items.Add($f.Name, $isTicked)
        }
        $Global:UclLoadingList = $false
        if ($lstTools.Items.Count -eq 0) { $txtResult.Text = 'No .js files in the tools folder yet: ' + $ToolsDir }
    } catch {
        $txtResult.Text = 'Could not read tools folder: ' + $_.Exception.Message
    }
    $Global:UclLoadingList = $false
}

$btnReloadList.Add_Click({ Update-ToolList; Restart-AutoLoad })

$btnLoadTool.Add_Click({
    $toolName = [string]$lstTools.SelectedItem
    if (-not $toolName) { $txtResult.Text = 'Select a tool in the list first.'; return }

    $txtResult.Text = 'Re-checking tab identity before loading ' + $toolName + '...'
    $form.Refresh()
    # Always re-identify right before running anything
    $cdp = Get-CdpInfo
    $sel = Get-WorkSelection
    $m   = Find-MatchingTarget -Selection $sel -Cdp $cdp
    if ($m.Status -ne 'MATCHED') {
        Update-Status
        $txtResult.Text = "BLOCKED - tool was NOT loaded.`r`nReason: " + $m.Status + ' - ' + $m.Detail
        return
    }
    try {
        $tf = @(Get-ToolFiles | Where-Object { $_.Name -eq $toolName }) | Select-Object -First 1
        if (-not $tf) { $txtResult.Text = 'Tool not found: ' + $toolName; return }
        $code = Read-ToolCode $tf
        $expr = New-ToolExpression -ToolName $toolName -Code $code
        $resp = Invoke-CdpEvaluate -WsUrl $m.Target.webSocketDebuggerUrl -Expression $expr
        if ($resp.error) {
            $txtResult.Text = 'CDP error: ' + $resp.error.message
        } elseif ($resp.result.exceptionDetails) {
            $txtResult.Text = "Tool has a code error (not loaded):`r`n" + $resp.result.exceptionDetails.text + ' ' + $resp.result.exceptionDetails.exception.description
        } else {
            $info = [string]$resp.result.result.value | ConvertFrom-Json
            $txtResult.Text = 'Tool    : ' + $toolName +
                "`r`nResult  : " + $info.status +
                "`r`nTab     : " + $m.Target.url +
                "`r`nLoaded on this page: " + (@($info.loaded) -join ', ')
        }
    } catch {
        $txtResult.Text = 'Loading failed: ' + $_.Exception.GetBaseException().Message
    }
})

$lstTools.Add_ItemCheck({
    param($sender, $e)
    if ($Global:UclLoadingList) { return }
    $name = [string]$lstTools.Items[$e.Index]
    $list = New-Object System.Collections.Generic.List[string]
    foreach ($c in $lstTools.CheckedItems) { if ([string]$c -ne $name) { $list.Add([string]$c) } }
    if ($e.NewValue -eq [System.Windows.Forms.CheckState]::Checked) { $list.Add($name) }
    $Global:UclSettings.checked = @($list)
    Save-Settings
    Restart-AutoLoad
})

# ---------------------------------------------------------------------
#  Settings window: closing it only hides it (the engine keeps running)
# ---------------------------------------------------------------------
$form.Add_FormClosing({
    param($sender, $e)
    if (-not $Global:UclQuitting) { $e.Cancel = $true; $form.Hide() }
})

function Show-SettingsWindow {
    Update-ToolList
    $form.Show()
    $form.WindowState = [System.Windows.Forms.FormWindowState]::Normal
    $form.Activate()
    Update-TrayStatus
    Update-Status
}

# ---------------------------------------------------------------------
#  Tray icon (the small dot near the clock)
# ---------------------------------------------------------------------
function New-DotIcon {
    param($Color)
    $bmp = New-Object System.Drawing.Bitmap 16, 16
    $g = [System.Drawing.Graphics]::FromImage($bmp)
    $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
    $g.Clear([System.Drawing.Color]::Transparent)
    $ring = New-Object System.Drawing.SolidBrush ([System.Drawing.Color]::FromArgb(15, 23, 42))
    $fill = New-Object System.Drawing.SolidBrush $Color
    $g.FillEllipse($ring, 1, 1, 14, 14)
    $g.FillEllipse($fill, 3, 3, 10, 10)
    $g.Dispose(); $ring.Dispose(); $fill.Dispose()
    return [System.Drawing.Icon]::FromHandle($bmp.GetHicon())
}

function Stop-Launcher {
    $Global:UclQuitting = $true
    $engineTimer.Stop()
    Close-AllUclSessions
    $tray.Visible = $false
    $tray.Dispose()
    $form.Close()
    [System.Windows.Forms.Application]::Exit()
}

# ---------------------------------------------------------------------
#  START (only one copy can run at a time)
# ---------------------------------------------------------------------
$Global:UclMutexCreated = $false
$Global:UclMutex = New-Object System.Threading.Mutex($true, 'Local\AtlasToolsLauncher', [ref]$Global:UclMutexCreated)
if (-not $Global:UclMutexCreated -and $env:ATLAS_TOOLS_RESTART -eq '1') {
    # Restart after an update: wait (up to 20 s) for the old copy to close
    try { $Global:UclMutexCreated = $Global:UclMutex.WaitOne(20000) }
    catch [System.Threading.AbandonedMutexException] { $Global:UclMutexCreated = $true }
}
$env:ATLAS_TOOLS_RESTART = $null
if ($Global:UclMutexCreated) {
    # The installer sets this signal to ask this copy to close
    try { $Global:UclQuitEvent = New-Object System.Threading.EventWaitHandle($false, [System.Threading.EventResetMode]::AutoReset, 'Local\AtlasToolsQuit') } catch { $Global:UclQuitEvent = $null }
}
if (-not $Global:UclMutexCreated) {
    [void][System.Windows.Forms.MessageBox]::Show('Atlas Tools v' + $LauncherVersion + ' is already running.' + [Environment]::NewLine + 'Look for its icon near the clock (bottom-right of the screen).', 'Atlas Tools')
} else {
    try {
        $IconOk   = New-DotIcon ([System.Drawing.Color]::FromArgb(34, 197, 94))
        $IconWait = New-DotIcon ([System.Drawing.Color]::FromArgb(245, 158, 11))

        $tray = New-Object System.Windows.Forms.NotifyIcon
        $tray.Icon = $IconWait
        $tray.Text = 'Atlas Tools v' + $LauncherVersion + ': starting'
        $menu = New-Object System.Windows.Forms.ContextMenuStrip
        $miVer = $menu.Items.Add('Atlas Tools v' + $LauncherVersion)
        $miVer.Enabled = $false
        $miStatus = $menu.Items.Add('Starting...')
        $miStatus.Enabled = $false
        [void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
        $miOpen = $menu.Items.Add('Open Atlas')
        $miSync = $menu.Items.Add('Sync tools now')
        $miSync.Add_Click({ $Global:UclSyncRequested = $true; $tray.ShowBalloonTip(2000, 'Atlas Tools', 'Syncing your tools...', [System.Windows.Forms.ToolTipIcon]::Info) })
        $miSettings = $menu.Items.Add('Settings and details')
        $miCheckUpd = $menu.Items.Add('Check for launcher update')
        $miCheckUpd.Add_Click({ $Global:UclUpd.Requested = $true; $Global:UclUpd.Manual = $true })
        $miRestart = $menu.Items.Add('Restart to update')
        $miRestart.Visible = $false
        $miRestart.Add_Click({ Restart-Launcher })
        [void]$menu.Items.Add((New-Object System.Windows.Forms.ToolStripSeparator))
        $miQuit = $menu.Items.Add('Quit Atlas Tools')
        $miOpen.Add_Click({ Start-WorkChrome })
        $miSettings.Add_Click({ Show-SettingsWindow })
        $miQuit.Add_Click({ Stop-Launcher })
        $tray.ContextMenuStrip = $menu
        $tray.Add_DoubleClick({ Show-SettingsWindow })
        $tray.Add_BalloonTipClicked({
            if (-not $Global:UclUpd.Ready) { return }
            $ans = [System.Windows.Forms.MessageBox]::Show('Restart Atlas Tools now to use version ' + $Global:UclUpd.Ready + '?' + [Environment]::NewLine + 'It takes a few seconds. Your WORK Chrome tabs stay open.', 'Atlas Tools update', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
            if ($ans -eq [System.Windows.Forms.DialogResult]::Yes) { Restart-Launcher }
        })
        $tray.Visible = $true

        $Global:UclSettings = Read-Settings
        $Global:UclSettings.autoload = $true
        $Global:UclSync = [pscustomobject]@{ status = $(if ($Global:UclSettings.email) { 'never' } else { 'no-email' }); n = 0; message = '' }
        $Global:UclCloudDesc = @{}
        if (-not $Global:UclSettings.token) {
            $Global:UclSettings.token = [guid]::NewGuid().ToString('N') + [guid]::NewGuid().ToString('N')
            Save-Settings
        }
        Read-GmStore
        Initialize-Http
        $Global:UclPerf = [pscustomobject]@{ RelayMs = 0; RelayMaxMs = 0; BusyMaxMs = 0; TabCheckMs = 0 }
        $Global:UclGmDirty = $false
        $Global:UclGmSnapAt = [datetime]::MinValue
        $Global:UclSyncRequested = $false
        $Global:UclSyncedThisRun = $false
        $Global:UclNextSyncTry = $null
        $Global:UclTickCount = 0
        $Global:UclConnected = $false
        $Global:UclLastError = ''
        $Global:UclQuitting = $false
        Update-ToolList

        # Open the WORK Chrome if it is not running yet (the engine connects on its first tick)
        $Global:UclSessions = @{}
        $Global:UclSessionIds = @{}
        $Global:UclAttaching = @{}
        $Global:UclBrowser = $null
        $Global:UclSyncTask = $null
        if (-not (Get-CdpInfo).Connected) { Start-WorkChrome }

        $engineTimer = New-Object System.Windows.Forms.Timer
        $engineTimer.Interval = 100
        $engineTimer.Add_Tick({
            $engineTimer.Stop()
            $tsw = [System.Diagnostics.Stopwatch]::StartNew()
            try { Invoke-EngineTick } catch { $Global:UclLastError = $_.Exception.Message }
            $ms = [int]$tsw.ElapsedMilliseconds
            if ($ms -gt $Global:UclPerf.BusyMaxMs) { $Global:UclPerf.BusyMaxMs = $ms }
            if (-not $Global:UclQuitting) { $engineTimer.Start() }
        })
        $engineTimer.Start()

        $tray.ShowBalloonTip(5000, 'Atlas Tools is running', 'Version ' + $LauncherVersion + '. Click the green dot next to your email in Atlas.', [System.Windows.Forms.ToolTipIcon]::Info)
        [System.Windows.Forms.Application]::Run()
    } catch {
        [void][System.Windows.Forms.MessageBox]::Show('Atlas Tools could not start:' + [Environment]::NewLine + $_.Exception.Message, 'Atlas Tools')
        try { if ($tray) { $tray.Visible = $false; $tray.Dispose() } } catch {}
    } finally {
        try { if ($Global:UclQuitEvent) { $Global:UclQuitEvent.Dispose() } } catch {}
        try { $Global:UclMutex.ReleaseMutex() } catch {}
    }
}
