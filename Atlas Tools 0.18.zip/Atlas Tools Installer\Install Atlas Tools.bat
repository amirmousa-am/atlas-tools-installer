@echo off
setlocal
title Atlas Tools setup
rem Installs or updates Atlas Tools for this Windows user. No admin rights needed.
set "ATLAS_SRC=%~dp0"
if not exist "%~dp0Install-AtlasTools.ps1" (
  echo.
  echo  Please extract the whole .zip file first ^(right-click it, "Extract All..."^),
  echo  then double-click "Install Atlas Tools" inside the extracted folder.
  echo.
  pause
  exit /b 1
)
echo Installing Atlas Tools, please wait...
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoProfile -Command "iex ([System.IO.File]::ReadAllText([System.IO.Path]::Combine($env:ATLAS_SRC, 'Install-AtlasTools.ps1')))"
endlocal
