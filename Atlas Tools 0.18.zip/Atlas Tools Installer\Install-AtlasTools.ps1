# =====================================================================
#  Atlas Tools - installer / updater (for the current Windows user only)
#  Started by "Install Atlas Tools.bat", or by pasting the line from
#  README.txt into PowerShell. Safe to run again for updates.
#  - copies AtlasTools.ps1 to %USERPROFILE%\Universal-Chrome-Launcher
#  - never deletes or changes tools\, gm-store\ or launcher-settings.json
#  - creates the "Atlas Tools" shortcut on the desktop and in the Start menu
#  No admin rights. Does NOT change the execution policy.
# =====================================================================
function Invoke-AtlasToolsInstall {
    Add-Type -AssemblyName System.Windows.Forms
    Add-Type -AssemblyName System.Drawing
    $title = 'Atlas Tools setup'
    $log = New-Object System.Collections.Generic.List[string]
    $owner = New-Object System.Windows.Forms.Form
    $owner.TopMost = $true
    $owner.ShowInTaskbar = $false
    $owner.StartPosition = 'CenterScreen'
    $owner.Size = New-Object System.Drawing.Size(1, 1)
    $owner.Opacity = 0

    function Write-Step([string]$Text) {
        $log.Add((Get-Date).ToString('yyyy-MM-dd HH:mm:ss') + '  ' + $Text)
        Write-Host $Text
    }
    function Show-Box([string]$Text, [string]$Buttons = 'OK', [string]$Icon = 'Information') {
        $owner.Show(); $owner.Activate()
        $r = [System.Windows.Forms.MessageBox]::Show($owner, $Text, $title, [System.Windows.Forms.MessageBoxButtons]$Buttons, [System.Windows.Forms.MessageBoxIcon]$Icon)
        $owner.Hide()
        return [string]$r
    }
    function Get-Ver([string]$Text) {
        $m = [regex]::Match($Text, "(?m)^\`$LauncherVersion\s*=\s*'(\d+(?:\.\d+){1,3})'")
        if ($m.Success) { return $m.Groups[1].Value } else { return '' }
    }
    function Test-Running {
        try { $m = [System.Threading.Mutex]::OpenExisting('Local\AtlasToolsLauncher'); $m.Dispose(); return $true }
        catch [System.Threading.WaitHandleCannotBeOpenedException] { return $false }
        catch { return $true }
    }
    function Wait-Closed([int]$Seconds) {
        $until = (Get-Date).AddSeconds($Seconds)
        while ((Get-Date) -lt $until) { if (-not (Test-Running)) { return $true }; Start-Sleep -Milliseconds 300 }
        return (-not (Test-Running))
    }
    function Stop-AtlasTools {
        # 1) polite: v0.18 and newer close themselves when asked
        try {
            $ev = [System.Threading.EventWaitHandle]::OpenExisting('Local\AtlasToolsQuit')
            [void]$ev.Set(); $ev.Dispose()
            Write-Step 'Asked Atlas Tools to close.'
            if (Wait-Closed 10) { return $true }
        } catch {}
        # 2) older versions (v0.17) cannot be asked: end the launcher's PowerShell
        $procs = @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" -ErrorAction SilentlyContinue |
            Where-Object { $_.ProcessId -ne $PID -and [string]$_.CommandLine -match 'Universal-Chrome-Launcher' })
        foreach ($p in $procs) {
            Write-Step ('Closing launcher process ' + $p.ProcessId)
            try { Stop-Process -Id $p.ProcessId -Force -ErrorAction Stop } catch { Write-Step ('  could not close it: ' + $_.Exception.Message) }
        }
        return (Wait-Closed 6)
    }

    $base = Join-Path $env:USERPROFILE 'Universal-Chrome-Launcher'
    try {
        # ---- 1. Find the package files ----
        $src = [string]$env:ATLAS_SRC
        if (-not $src) { $src = (Get-Location).ProviderPath }
        $src = $src.Trim().Trim('"')
        $pkg = Join-Path $src 'AtlasTools.ps1'
        Write-Step ('Package folder: ' + $src)
        if (-not (Test-Path -LiteralPath $pkg)) {
            if ($src -match '\\(Temp|Temporary Internet Files)\\' -or $src -match '\.zip') {
                [void](Show-Box ('It looks like you opened the installer from inside the .zip file.' + [Environment]::NewLine + [Environment]::NewLine + 'Please right-click the .zip file, choose "Extract All...", open the extracted folder and double-click "Install Atlas Tools" there.') 'OK' 'Warning')
            } else {
                [void](Show-Box ('AtlasTools.ps1 was not found next to the installer:' + [Environment]::NewLine + $src + [Environment]::NewLine + [Environment]::NewLine + 'Extract the whole .zip first, then run the installer from the extracted folder.') 'OK' 'Warning')
            }
            return
        }
        $bytes = [System.IO.File]::ReadAllBytes($pkg)
        foreach ($by in $bytes) { if ($by -gt 127) { throw 'AtlasTools.ps1 in this package is damaged (not plain text). Please get a fresh copy of the .zip.' } }
        $text = [System.Text.Encoding]::ASCII.GetString($bytes)
        $newVer = Get-Ver $text
        if (-not $newVer -or -not $text.StartsWith('# =====') -or $text.IndexOf('Atlas Tools Launcher') -lt 0) {
            throw 'AtlasTools.ps1 in this package is not the Atlas Tools launcher. Please get a fresh copy of the .zip.'
        }
        Write-Step ('Package version: ' + $newVer)

        # ---- 2. Compare with what is installed ----
        $dest = Join-Path $base 'AtlasTools.ps1'
        $copy = $true
        $oldVer = ''
        if (Test-Path -LiteralPath $dest) { $oldVer = Get-Ver ([System.IO.File]::ReadAllText($dest)) }
        if ($oldVer) {
            Write-Step ('Installed version: ' + $oldVer)
            if ([version]$oldVer -gt [version]$newVer) {
                $a = Show-Box ('A NEWER version of Atlas Tools is already installed (v' + $oldVer + ').' + [Environment]::NewLine + 'This package has v' + $newVer + '.' + [Environment]::NewLine + [Environment]::NewLine + 'Yes = keep v' + $oldVer + ' (recommended)' + [Environment]::NewLine + 'No = replace it with the older v' + $newVer) 'YesNo' 'Question'
                if ($a -eq 'Yes') { $copy = $false; Write-Step 'Keeping the newer installed version.' }
            }
        }

        # ---- 3. Is Atlas Tools running? ----
        $running = Test-Running
        if ($running -and $copy) {
            $a = Show-Box ('Atlas Tools is running right now.' + [Environment]::NewLine + [Environment]::NewLine + 'Yes = close it for me, then install (recommended)' + [Environment]::NewLine + 'No = install anyway; the new version starts the next time you open Atlas Tools' + [Environment]::NewLine + 'Cancel = stop, change nothing' + [Environment]::NewLine + [Environment]::NewLine + 'Your WORK Chrome window and tabs stay open either way.') 'YesNoCancel' 'Question'
            if ($a -eq 'Cancel') { Write-Step 'Cancelled by user.'; return }
            if ($a -eq 'Yes') {
                if (Stop-AtlasTools) { $running = $false; Write-Step 'Atlas Tools is closed.' }
                else { [void](Show-Box ('Atlas Tools could not be closed automatically.' + [Environment]::NewLine + 'Setup continues. Afterwards, right-click the Atlas Tools icon near the clock, choose "Quit Atlas Tools", then start it again from the desktop.') 'OK' 'Warning') }
            }
        }

        # ---- 4. Copy the launcher (your tools, data and settings are not touched) ----
        if (-not (Test-Path -LiteralPath $base)) { [void](New-Item -ItemType Directory -Path $base -Force); Write-Step ('Created ' + $base) }
        if ($copy) {
            $tmp = $dest + '.new'
            [System.IO.File]::WriteAllBytes($tmp, $bytes)
            if (Test-Path -LiteralPath $dest) { [System.IO.File]::Replace($tmp, $dest, (Join-Path $base 'AtlasTools.previous.ps1')) }
            else { [System.IO.File]::Move($tmp, $dest) }
            Write-Step ('Installed AtlasTools.ps1 v' + $newVer)
        }
        foreach ($extra in 'atlas-tools.ico', 'README.txt') {
            $f = Join-Path $src $extra
            if (Test-Path -LiteralPath $f) { Copy-Item -LiteralPath $f -Destination (Join-Path $base $extra) -Force }
        }

        # ---- 5. Shortcuts (desktop works with OneDrive desktops too) ----
        $psExe = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $args1 = '-NoProfile -WindowStyle Hidden -Command "iex (Get-Content -Raw (Join-Path $env:USERPROFILE ''Universal-Chrome-Launcher\AtlasTools.ps1''))"'
        $icon = Join-Path $base 'atlas-tools.ico'
        $wsh = New-Object -ComObject WScript.Shell
        $places = @([Environment]::GetFolderPath('Desktop'), [Environment]::GetFolderPath('Programs')) | Where-Object { $_ }
        if (-not $places) { throw 'The desktop folder could not be found.' }
        foreach ($dir in $places) {
            if (-not (Test-Path -LiteralPath $dir)) { continue }
            $lnkPath = Join-Path $dir 'Atlas Tools.lnk'
            $lnk = $wsh.CreateShortcut($lnkPath)
            $lnk.TargetPath = $psExe
            $lnk.Arguments = $args1
            $lnk.WorkingDirectory = $base
            $lnk.WindowStyle = 7
            $lnk.Description = 'Start Atlas Tools (WORK Chrome with your Atlas tools)'
            if (Test-Path -LiteralPath $icon) { $lnk.IconLocation = $icon + ',0' } else { $lnk.IconLocation = $psExe + ',0' }
            $lnk.Save()
            Write-Step ('Shortcut: ' + $lnkPath)
        }
        [void][System.Runtime.InteropServices.Marshal]::ReleaseComObject($wsh)

        # ---- 6. Done ----
        $doneVer = if ($copy) { $newVer } else { $oldVer }
        if ($running) {
            [void](Show-Box ('Done. Atlas Tools v' + $doneVer + ' is installed.' + [Environment]::NewLine + [Environment]::NewLine + 'The old copy is still running. To use the new version: right-click the Atlas Tools icon near the clock, choose "Quit Atlas Tools", then double-click "Atlas Tools" on your desktop.') 'OK' 'Information')
        } else {
            $a = Show-Box ('Done. Atlas Tools v' + $doneVer + ' is installed.' + [Environment]::NewLine + [Environment]::NewLine + 'From now on, just double-click "Atlas Tools" on your desktop.' + [Environment]::NewLine + [Environment]::NewLine + 'Start Atlas Tools now?') 'YesNo' 'Information'
            if ($a -eq 'Yes') {
                $env:ATLAS_TOOLS_RESTART = $null
                Start-Process -FilePath $psExe -ArgumentList $args1 -WindowStyle Hidden
                Write-Step 'Started Atlas Tools.'
            }
        }
    } catch {
        Write-Step ('ERROR: ' + $_.Exception.Message)
        [void](Show-Box ('Atlas Tools setup did not finish:' + [Environment]::NewLine + $_.Exception.Message + [Environment]::NewLine + [Environment]::NewLine + 'Nothing of your tools or settings was deleted. Send a screenshot of this message to your Atlas Tools contact.') 'OK' 'Error')
    } finally {
        try {
            if (Test-Path -LiteralPath $base) { [System.IO.File]::AppendAllText((Join-Path $base 'install-log.txt'), (($log -join "`r`n") + "`r`n")) }
        } catch {}
        try { $owner.Dispose() } catch {}
    }
}
Invoke-AtlasToolsInstall
